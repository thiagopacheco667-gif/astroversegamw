const C='iron-front-v10-8',F=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-192.png','icon-maskable-512.png','apple-touch-icon.png','img/mesa/madeira.webp','img/mesa/mapa.webp','img/mesa/mapa-m.webp','img/objetos/documentos.webp','img/objetos/municao.webp','img/objetos/relogio.webp','img/objetos/bussola.webp','audio/ambiente/vento_loop.wav','audio/artilharia/canhao_campanha_tiro.wav','audio/artilharia/obus_pesado_tiro.wav','audio/explosoes/explosao_media.wav','audio/explosoes/explosao_pequena.wav','audio/explosoes/explosao_pesada.wav','audio/infantaria/ferrolho_recarga_1.wav','audio/infantaria/ferrolho_recarga_2.wav','audio/infantaria/ferrolho_recarga_3.wav','audio/infantaria/ferrolho_recarga_4.wav','audio/infantaria/rifle_tiro_1.wav','audio/infantaria/rifle_tiro_2.wav','audio/infantaria/rifle_tiro_3.wav','audio/infantaria/rifle_tiro_4.wav','audio/infantaria/rifle_tiro_5.wav','audio/metralhadoras/maxim_mg08_rajada_1.wav','audio/metralhadoras/maxim_mg08_rajada_2.wav','audio/metralhadoras/metralhadora_aviao_rajada.wav','audio/metralhadoras/vickers_rajada_1.wav','audio/metralhadoras/vickers_rajada_2.wav'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
 const q=e.request;
 if(q.method!=='GET'||new URL(q.url).origin!==location.origin)return;
 e.respondWith(fetch(q).then(r=>{
  if(r.ok){const cp=r.clone();caches.open(C).then(c=>c.put(q,cp))}
  return r;
 }).catch(()=>caches.match(q,{ignoreSearch:true}).then(m=>m||(q.mode==='navigate'?caches.match('./'):undefined))));
});
