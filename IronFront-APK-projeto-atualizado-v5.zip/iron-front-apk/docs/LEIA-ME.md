# Iron Front — v10.8 (fortificação)

## Como abrir
O jogo carrega os áudios com `fetch`, então precisa ser aberto por um servidor (hospedagem, GitHub Pages, Netlify ou
`python3 -m http.server` na pasta). Abrindo o `index.html` direto do disco (file://) o navegador bloqueia os
arquivos e o jogo usa os sons sintetizados antigos (continua jogável, sem os sons gravados).

## O que mudou
Somente áudio, mixer e menu. Regras, cartas, IA, tutorial, salvamento e visual do jogo não foram alterados.
- `audio/` com 20 arquivos organizados em pastas (infantaria, metralhadoras, artilharia, explosoes, ambiente).
- Cada ataque agora dispara o som no momento real da animação: disparo → trajeto → impacto (antes todos os sons
  eram agendados juntos no início, com atrasos fixos).
- Se um arquivo não carregar, o jogo usa automaticamente o som sintetizado antigo daquele efeito.
- Menu: botão de ambiente e volumes (geral, efeitos, ambiente), salvos no aparelho.
- Variação aleatória entre gravações, redução do vento durante explosões grandes, sons cortados ao iniciar nova partida e
  2,8 s após o fim da batalha, áudio suspenso com a aba em segundo plano.

## Correção v10.1 — ataques rápidos de várias unidades
Problema relatado: sons atropelados, cortados ou ausentes quando várias unidades atacam em sequência.
Causas encontradas e correções:
1. As explosões médias tinham 215 ms de silêncio no início do arquivo (saíam atrasadas em relação ao impacto). Recortado.
2. Caudas de 4 s de explosões e tiros de obus se acumulavam (5 sons longos ao mesmo tempo) e o compressor derrubava o
   volume dos tiros seguintes (até −9,5 dB). Agora cada novo ataque apaga suavemente (≈0,8 s) as caudas dos anteriores,
   as caudas ficam mais curtas e o tiro da peça de artilharia se apaga quando a explosão chega.
3. Compressor trocado por um limitador só de picos e ganhos reduzidos (redução máxima caiu para ≈−2 dB).
4. Limite de vozes subiu de 12 para 20, e o excesso é resolvido com fade suave, sem descartar sons importantes.
Medido no teste de turno da IA com 10 unidades: pior caso do som novo sobre a cauda anterior foi de −16,9 dB para −0,7 dB.
Obs.: o volume geral ficou ≈3 dB mais baixo que na v10; use o controle de volume do menu se quiser mais.
- `sw.js` atualizado (cache `iron-front-v10`) com os novos arquivos.

## Associação som → carta
| Ação | Som |
|---|---|
| Infantaria ataca | salva de 2–3 tiros de rifle (5 gravações) + ferrolho depois do impacto |
| Metralhadora Vickers (a3) | vickers_rajada (2 variações) |
| Metralhadora MG 08 (c3) | maxim_mg08_rajada (2 variações) |
| Canhão 75 mm / FK 96 | canhao_campanha_tiro; explosão média no alvo (pesada se for o QG) |
| Obus BL 9,2 / Grande Berta | obus_pesado_tiro; explosão pesada |
| Sopwith Camel / Fokker Dr.I | motor (sintetizado) + metralhadora_aviao_rajada + impacto |
| BE2 / Taube (reconhecimento) | motor (sintetizado) + impacto leve, sem metralhadora |
| Barragem de Artilharia / Fogo de Barragem | assobio (sintetizado) + explosão média |
| Unidade destruída | explosão pequena (omitida quando uma explosão acabou de tocar, para não duplicar) |
| Ambiente | vento em loop |

## Ainda faltam (hoje usam o som sintetizado antigo)
1. Motor de biplano/triplano e passagem aérea (Sopwith Camel, Fokker Dr.I, BE2, Taube).
2. Motor pesado, esteiras e tiro de canhão de tanque (Mark IV, Renault FT, A7V).
3. Assobio de projétil de artilharia (o arquivo "incoming" enviado não tem um assobio separado que eu tenha identificado).
4. Impactos de projétil: terra, madeira, metal e ricochete (usados por infantaria, aviões, tanques e dano ao QG).
5. Operações: reforços chegando (marcha/botas) e suprimentos (caixas, equipamento).
6. Tiros e explosões distantes para o ambiente (hoje o ambiente é só o vento).
7. Uma metralhadora de avião específica (a gravação usada é genérica) e rifles diferenciados por país.
Nomes sugeridos: `aviao_motor_biplano`, `aviao_passagem`, `tanque_motor`, `tanque_esteiras`, `tanque_tiro`,
`projetil_assobio`, `impacto_terra`, `impacto_madeira`, `impacto_metal`, `ricochete`, `reforcos_marcha`,
`suprimentos_caixas`, `ambiente_tiros_distantes`.

## Pontos para você conferir de ouvido
- `obus_pesado_tiro` vem do arquivo cujo título original é "bassy lasery atomic explosion" (idêntico ao seu
  heavy_artillery_firing.wav). Por análise do espectro soa como estrondo largo, mas confirme que combina com um obus.
- O volume de cada categoria (`g:` em `AUD`, dentro do `index.html`) foi definido por medição, não de ouvido; ajuste se precisar.

## Testes feitos (Chromium headless)
Carregamento e decodificação dos 20 arquivos; ataques de todos os tipos de unidade, do jogador e da IA, contra unidade e QG;
tempo de cada som em relação ao impacto; mudo/retorno; vozes zeradas ao iniciar nova partida; menu em 3 tamanhos de tela;
volumes salvos após recarregar; sem erros de JavaScript.
Não testado: celulares reais (iOS/Android), escuta humana e instalação do PWA offline.

## v10.2 — equilíbrio entre as facções
Medido com um simulador (IA contra IA, 3000 partidas por teste): antes os Aliados venciam ~72%; agora ~51%.
- **Mark IV:** vida 5 → 4.
- **A7V:** ganha COURAÇA e o baralho das Potências Centrais passa de 1 para 2 cópias (Infantaria Búlgara: 2 → 1).
- **Landser:** CAI: CURA (QG +1). **Soldados Otomanos:** ENTRA +CARTA.
- **Infiltração:** o atacante não sofre contra-ataque.
- **Assalto:** no primeiro ataque (turno em que entra) causa +1 de dano.
- Tutorial: os Otomanos do tutorial não compram carta (para não mudar o roteiro).
- `sw.js`: cache `iron-front-v10-2`.
Pendente das sugestões: retaguarda intocável, comando sobrando após o turno 7, turno 1 vazio, cartas fracas (Barragem, Suprimentos, reações).
Ressalva: o simulador é uma reimplementação das regras com IA simples; confirme jogando.

## v10.3 — ritmo da partida
Simulador (3000 partidas por teste): as duas fases do jogo (comando apertado até o turno 6; comando sobrando e mão vazia depois) viraram uma só.
- **Teto de comando 10 → 7** (`CFG.maxCp`).
- **A partir do 7º turno, compra 2 cartas por turno** (`CFG.drawAt`).
- **Quem joga em segundo começa com +1 de comando no 1º turno** (compensação: sem ela quem joga primeiro vencia ~64% nos espelhos; com ela, ~55–57%).
- No simulador, do turno 8 em diante sobra ~0,5 de comando e ficam ~3,7 cartas na mão (antes: 2,1 de comando sobrando e 1,7 cartas).
- Equilíbrio Aliados × Centrais: ~47% / 53% (média entre jogar primeiro e segundo).
- `sw.js`: cache `iron-front-v10-3`.
Atenção: Mobilização (+1 comando no 5º turno) e o comandante Pershing (+2 no turno seguinte) ficam mais fracos com o teto 7. Revisar.

## v10.4 — comandantes e Mobilização
Medição (3000 partidas): com o teto 7, o Pershing (custo 1, +2 de comando no turno seguinte) era o comandante mais forte (Aliados 63% só com ele), o Haig o mais fraco (33%) e o Falkenhayn o mais fraco dos Centrais. Não era o Pershing que estava fraco, como eu havia suposto.
- **Pershing:** custo 1 → 2.
- **Haig:** custo 2 → 1.
- **Hindenburg:** custo 1 → 2.
- **Falkenhayn:** custo 3 → 2.
- **Mobilização:** além do +1 de comando no 5º turno, o teto dos Aliados sobe para 8 a partir dele.
- Resultado medido no arquivo final: Aliados ~52,5% / Centrais ~47,5%. Com cada comandante fixo, os Aliados ficam entre 50,5% e 52,5% (antes 33–63%) e, contra cada comandante dos Centrais, entre 48,5% e 53,5%.
- `sw.js`: cache `iron-front-v10-4`.

## v10.5 — compensação do segundo jogador
Simulador (5000 partidas por teste), vantagem de quem joga primeiro nos espelhos (A×A e C×C):
| Compensação do 2º jogador | 1º jogador vence (média) | Aliados × Centrais |
|---|---|---|
| +1 comando no turno 1 (v10.3/10.4) | 57% | 52,4% |
| +1 comando + 7 cartas iniciais | 54% | 50,8% |
| **+2 comando no turno 1 (v10.5)** | **50%** (A 49%, C 50%) | 49,3% |
- Quem joga em segundo começa o 1º turno com 3 de comando (1 + 2) e mão inicial de 5 cartas, como antes.
- `sw.js`: cache `iron-front-v10-5`.

## v10.6 — Última cartada e indicador ▶ de "entra atacando"
**Última cartada (vale para o jogador e para a IA).** A partir do 7º turno do lado (`CFG.lsAt`), no início do turno o jogo confere:
- o inimigo tem 3 ou mais cartas a mais (`CFG.lsDiff`), contando mão + unidades em campo + reações; **e**
- o lado em desvantagem tem 4 cartas ou menos (`CFG.lsFew`) **ou** o QG em 8 ou menos (`CFG.lsHq`).
Se as duas condições valem, a **primeira unidade mobilizada em cada turno ataca no mesmo turno** (sem o +1 de dano do Assalto). A checagem é feita só no início do turno (não dá para manipular durante a jogada) e a habilidade desliga sozinha quando o jogo se equilibra. Os 4 valores ficam no `CFG` do `index.html` para ajuste fino.
- Aviso na tela ao ativar, linha "▶ Última cartada" no painel e texto no QG; entrada nova no glossário (menu).
**Triângulo verde ▶** (abaixo do número de custo) nas cartas que entram atacando: Assalto e Infiltração sempre; nas cartas na mão, também nos 3 primeiros turnos das Potências Centrais (Schlieffen) e quando a Última cartada está ativa. O triângulo usa a mesma regra do jogo, então não mente. Segure o dedo na carta para ler a explicação. O ▲ vermelho (pronta) continua igual.
- `sw.js`: cache `iron-front-v10-6`.
Testado em Chromium headless: ativação e desativação (turno 6, diferença de 2 cartas, mão e QG), só 1 unidade por turno, triângulos somem após o uso, IA usando a regra, sem erros de JavaScript.
**Não testado:** equilíbrio. Esta regra não foi medida no simulador; rode as 5000 partidas antes de considerar fechada. Também não testado em celular real.

## v10.7 — mesa de comando (só visual)
Regras, cartas, IA, tutorial, salvamento e áudio não foram alterados na parte visual (exceto a correção v10.7.1 abaixo).
- Nova camada `#table` (dentro de `#app`, atrás das colunas) com o mapa topográfico, os objetos e uma vinheta. Fica fora de `#B`, `#L` e `#H`, que o `render()` reconstrói a cada ação.
- Imagens em `img/` (WebP): `mesa/madeira`, `mesa/mapa` (+ `mapa-m` para telas pequenas), `objetos/relogio`, `bussola`, `municao`, `documentos`. Todas pré-cacheadas no `sw.js` (cache `iron-front-v10-7`).
- Objetos recortados com sombra embutida e ajustados à Primeira Guerra: bússola "MK. VI · 1916" (sem "U.S. ARMY"), caixa de munição ".303 BRIT. / BALL MK VII / 5 RD CLIPS / LOT RL 16-7", relatório datado "12. Juni 1916", estrelas do mapa trocadas por círculos concêntricos. A pasta "Operation Overlord" não foi usada.
- Grade do `#B`: uma faixa de 12 px entre as duas linhas de frente deixa a trincheira do mapa à mostra (o arame em CSS foi removido). As fileiras ficam ~7% mais baixas.
- O mapa é ancorado ao centro de `#B` (`top:calc(50% - 52px)`), então a trincheira acompanha a linha de frente em qualquer proporção de tela.
- Para ajustar: posições e tamanhos dos objetos estão nas regras `.tb-*` no fim do `<style>`.
Testado em Chromium headless (1280×600, 1600×680, 844×390, 667×375): partida jogada por vários turnos sem erros de JavaScript. Não testado em celular real.

## v10.7.1 — Campo Minado
Antes, a mina causava 3 de dano ao primeiro blindado inimigo, mas o ataque continuava: um A7V (5♥) sobrevivia com 2♥, matava o soldado e ficava com 1♥ após o contra-ataque.
Agora, se o blindado sobreviver à mina, **perde o ataque** daquele turno (o soldado fica intacto). Se a mina o destruir, nada muda. Arame, Contrabateria e Antiaérea continuam como antes.
Alterado: `fireRx` (guarda `G.rxk`), `attack` (cancela o ataque quando a reação é a mina) e o texto de MINAS no glossário. Testado com A7V e Mark IV, com e sem reação, e com Arame Farpado.

## v10.7.2 — tabuleiro elevado e acessórios com forma
- **Tabuleiro elevado:** moldura com espessura nos 4 lados (bisel claro em cima/esquerda, escuro embaixo/direita, rebites de latão nos cantos) e sombra projetada. Regras `.tb-board`, `::before`, `::after` e `.tb-rv`.
- **Acessórios refeitos:** a faixa de documentos com bordas esmaecidas (parecia papel translúcido) foi substituída por objetos separados com borda real: relatório "Lagebericht 12. Juni 1916", pasta "GEHEIM · Somme 1916" e lápis, todos gerados por código. Munição, bússola e relógio foram clareados, girados e receberam sombra de contato + sombra projetada (luz do alto-esquerda).
- Os objetos ficam acima da vinheta (antes eram escurecidos por ela). Vinheta mais leve; painel direito mais transparente na borda para a moldura aparecer.
- `sw.js`: cache `iron-front-v10-7-2`.

## v10.8 — fortificação (Sapador e barricadas)
Só o que está descrito aqui mudou; as demais regras, cartas e o visual continuam como na v10.7.2.

**Carta Sapador** (uma por facção): Aliados "Sapadores Reais" (Império Britânico), Potências Centrais "Pioniere" (Império Alemão). Infantaria (ocupa a frente), custo 2, ataque 0, vida 2, habilidade `build` (etiqueta CONSTRÓI). Não ataca; pode ser atacado normalmente e, com ataque 0, não causa contra-ataque. 2 cópias por facção; as cartas Suprimentos (a14/c14) saíram dos baralhos (continuam em `CARDS` e no Arquivo). Arte SVG de fallback (soldado de capacete com pá atrás de sacos de areia). Não consome a Última cartada, não entra pronto (nem pelo Plano Schlieffen) e não recebe o ▶, e não entra nas 2 cartas baratas garantidas da mão inicial.

**Barricada** (`bar[5]` por lado, valor = vida): terreno por casa da frente, não ocupa o lugar de uma unidade. Vida 3, máximo 2 por lado, uma por casa. Construção instantânea: Sapador pronto (não recém-mobilizado, ainda não agiu) → casa da própria frente sem barricada; custa 1 de comando e usa a ação do Sapador. Se o Sapador cair, as barricadas continuam.

**Proteção.** A barricada cobre a própria casa e as duas vizinhas laterais, mas só protege unidades FERIDAS (vida atual < vida máxima da carta). O dano vai primeiro à barricada; o transbordo vai à unidade; chegando a 0, a barricada é destruída. Vida cheia não é protegida. Vale para ataques normais, para o respingo da Barragem do obus (-1 nos vizinhos) e para a operação Barragem de Artilharia (3). Não vale para dano ao QG, reações, explosão de blindado nem efeitos de comandante. O contra-ataque do defensor continua acontecendo.
Detalhes de implementação (não estavam na especificação):
- Com duas barricadas cobrindo a mesma casa, absorve a da própria casa; se não houver, a vizinha com mais vida (empate: a da esquerda). Só uma barricada absorve por golpe.
- O contra-ataque que o defensor causa ao atacante não passa por barricada (só ataque, respingo e Barragem).
- A retaguarda nunca é coberta.

**Interface.** Sapador pronto selecionado (toque, ou arrastando até a casa): as casas da frente sem barricada ganham "+" e um toast explica; tocar na própria casa do Sapador também constrói ali. Selo "🧱N" no canto da casa, destaque dourado na casa e contorno tracejado nas vizinhas cobertas. Toasts: "Construir custa 1 de comando.", "Limite de 2 barricadas no seu lado.", "Já há uma barricada nesta casa.". "🧱" no número flutuante quando a barricada absorve todo o dano. Etiqueta CONSTRÓI no glossário (toque longo) e item "BARRICADAS 🧱" na Enciclopédia.

**IA.** Joga o Sapador como qualquer unidade. No início do turno, com um Sapador pronto e 1 de comando, constrói na coluna que cobre mais unidades feridas, ponderando custo da carta e vida perdida (se nenhuma unidade ferida seria coberta, não constrói e não gasta comando); na dificuldade fácil, só em ~50% das vezes (medido: 93/200). O Sapador nunca ataca no loop de ataques. Na avaliação de alvos (ataques e Barragem), a IA desconta a absorção da barricada ao decidir se consegue matar.

**Salvamento.** `bar[]` entra no estado de cada lado e na restauração. Partida antiga (sem `bar`) restaura com `[0,0,0,0,0]`; valores inválidos são saneados (máx. 2 barricadas, vida ≤ 3).

**Versão.** `sw.js`: cache `iron-front-v10-8`. APK: `versionName` 10.8.N.

**Atenção — equilíbrio não re-simulado.** Aliados e Potências Centrais ganharam a mesma carta, mas as 5000 partidas do simulador não foram rodadas. Nota: cada baralho passou de 32 para 33 cartas (saiu 1 Suprimentos, entraram 2 Sapadores).

**Testado em Chromium headless (844×390):** construir com clique real e arrastando; limite de 2; "Já há"; sem comando; unidade ferida coberta absorve; vida cheia não é protegida; transbordo (barricada de 1 e golpe de 3); casa fora da cobertura e retaguarda; respingo do obus e Barragem de Artilharia; QG, explosão, comandante e reação ignoram a barricada; contra-ataque preservado; sapador não ataca nem entra pronto (Última cartada e Schlieffen); partida salva e restaurada com barricadas, save antigo e save adulterado; IA (coluna, ponderação, limite, fácil ≈ 50%, turno completo sem ataque do sapador); 12 partidas completas contra a IA (3 dificuldades × 2 facções × 2 rodadas), todas terminaram sem erros de JavaScript. **Não testado:** celular real e o build do APK.
