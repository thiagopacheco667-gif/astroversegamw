# Iron Front: The Great War — APK Android

Jogo de cartas estratégico da Primeira Guerra Mundial (v10.8), empacotado como app Android.
O jogo roda 100% offline dentro de um WebView em tela cheia, em paisagem; partida salva, opções e estatísticas
ficam guardadas no aparelho.

## Baixar e instalar no celular
1. No GitHub, abra **Releases → "Iron Front (último build)"** e baixe `IronFront.apk` (pelo navegador do celular).
2. Abra o arquivo. Na primeira vez o Android pede para permitir "instalar apps desconhecidos" para o navegador/gerenciador de arquivos.
3. Instale e abra "Iron Front".

Atualizações: instale o APK novo por cima; partida salva e estatísticas são mantidas
(desde que o APK seja assinado pela mesma chave — veja abaixo).

## Como gerar o APK (primeira vez)
1. Crie um repositório no GitHub e suba **todo o conteúdo desta pasta** (inclusive `.github/` e `keystore/`).
2. Vá em **Actions → Build APK**. O build roda sozinho a cada push na branch `main` (ou clique em *Run workflow*).
3. Em ~5 min o APK aparece em **Releases** (e também como *artifact* da execução).
4. Para uma versão fixa: `git tag v10.8 && git push --tags`.

## Assinatura
Por padrão o APK é assinado com `keystore/ironfront-sideload.jks` (senha `ironfront`), uma chave só para instalar
no seu celular. Ela é pública se o repositório for público: **use repositório privado** ou troque pela sua chave:
```
keytool -genkeypair -keystore minha.jks -alias iron -keyalg RSA -keysize 2048 -validity 36500
base64 -w0 minha.jks      # copie a saída
```
Em *Settings → Secrets and variables → Actions* crie `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Trocar a chave exige desinstalar o app antes (o Android não aceita atualização com assinatura diferente).
Para publicar na Play Store seria preciso gerar um AAB com chave própria — este projeto não cobre isso.

## Estrutura
- `app/src/main/assets/www/` — o jogo (index.html, img/, audio/). Para atualizar o jogo, substitua esta pasta.
- `app/src/main/java/.../MainActivity.java` — WebView, tela cheia imersiva, tela sempre ligada, "voltar duas vezes para sair".
- `docs/` — LEIA-ME e créditos de áudio do jogo.

## Mudanças em relação ao PWA
Só uma linha no `index.html`: o service worker não é registrado dentro do app (os arquivos já estão no APK).
O restante do jogo é idêntico à v10.8.

## Atenção: licenças dos áudios
`docs/CREDITOS.md` lista as licenças dos sons como **a confirmar**. Confirme antes de publicar o APK publicamente.
