/* Iron Front — core/state.js
 * Estado mutável da sessão de jogo (partida atual, tutorial, facção/dificuldade escolhidas, partida salva em memória). Outros módulos leem pelas ligações vivas (live bindings) e escrevem pelos setters set_*.
 */
export let G=null;
export let uid=0;
export let gidc=0;
export let TUT=null;
export let pf='a';
export let diff='normal';
export let SAVED=null;
export const set_G=v=>G=v;
export const set_pf=v=>pf=v;
export const set_diff=v=>diff=v;
export const set_TUT=v=>TUT=v;
export const set_SAVED=v=>SAVED=v;
export const set_uid=v=>uid=v;
export const next_uid=()=>++uid;
export const next_gidc=()=>++gidc;
