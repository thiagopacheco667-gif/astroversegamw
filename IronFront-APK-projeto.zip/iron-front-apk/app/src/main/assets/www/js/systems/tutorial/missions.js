/* Iron Front — systems/tutorial/missions.js
 * Missões do Treinamento (MIS_DEF) e suas montagens de cena.
 */
import {G, TUT, gidc, next_gidc, next_uid, set_G, uid} from '../../core/state.js';
import {CARDS} from '../../data/cards.js';
import {CFG, NAMES} from '../../data/config.js';
import {side} from '../battle/engine.js';
import {mkSoldier} from '../soldiers.js';

export const MU=(id,o={})=>{const c={...CARDS[id],uid:next_uid(),ready:true,att:false,bt:0,fr:0,imm:false,sho:0,...o};c.sd=mkSoldier(c);return c};
export const MCOUNT=k=>G.s[k].front.concat(G.s[k].rear).filter(Boolean).length;
export const MREADY=()=>G.s.p.front.concat(G.s.p.rear).some(u=>u&&u.ready&&!u.att);
function misBase(cp){set_G({id:next_gidc(),s:{p:side('a'),e:side('c')},turn:'p',busy:false,over:false,sel:null,detail:null,log:['Missão iniciada.'],n:1,names:{p:NAMES.a,e:NAMES.c}});for(const k of['p','e']){const Q=G.s[k];Q.deck=[];Q.hand=[];Q.hq=30;Q.tn=4;Q.max=cp;Q.cp=cp}return G}
export const MIS_DEF={
rev:{ic:'↩',t:'Revide',s:'Destrua uma unidade inimiga sem perder nenhuma das suas.',
x:'Destrua UMA unidade inimiga sem perder nenhuma das suas. Escolha um atacante e leia o aviso de risco nos alvos: ↩ -N é o revide, ☠ é a sua unidade caindo. Dica: artilharia não sofre revide.',
setup(){const g=misBase(0),P=g.s.p,E=g.s.e;P.front[1]=MU('a1');P.front[2]=MU('a4');P.rear[1]=MU('a6');E.front[0]=MU('c4');E.front[1]=MU('c1',{hp:1});E.front[2]=MU('c5');TUT.d={pn:3,en:3}},
check(){if(MCOUNT('p')<TUT.d.pn)return['fl','Uma das suas unidades caiu junto com o ataque. Reinicie e confira o aviso ☠ antes de atacar.'];if(MCOUNT('e')<TUT.d.en)return['ok','Muito bem! Você atacou onde o revide não mata a sua unidade: a artilharia não sofre revide, e um alvo fraco devolve pouco.'];if(!MREADY())return['fl','Suas unidades já agiram e nada foi destruído. Reinicie e procure o alvo certo.']}},
gua:{ic:'🛡',t:'Guarda',s:'Destrua a artilharia que se esconde atrás da Guarda.',
x:'A Metralhadora tem GUARDA: os terrestres precisam atacá-la primeiro, e o canhão inimigo fica escondido atrás. Destrua o canhão. Dica: só um tipo de unidade ignora a linha de frente.',
setup(){const g=misBase(0),P=g.s.p,E=g.s.e;P.front[2]=MU('a2');P.rear[1]=MU('a10');P.rear[3]=MU('a6');E.front[2]=MU('c3');E.rear[2]=MU('c6')},
check(){if(!G.s.e.rear.some(Boolean))return['ok','Isso! A aviação ignora a linha de frente e a Guarda. Ela sofreu 1 de dano antiaéreo por causa da Guarda inimiga, e esse é o preço.'];if(!MREADY())return['fl','O canhão continua de pé. Só a aviação passa por cima da Guarda. Reinicie e tente de novo.']}},
rea:{ic:'⚡',t:'Reação',s:'Arme o Arame Farpado e encerre o turno.',
x:'Reações ficam ocultas e disparam sozinhas no turno do inimigo. Toque duas vezes no Arame Farpado (custa 2) para armá-lo e encerre o turno: a infantaria inimiga que atacar sofre 2 de dano.',end:1,
setup(){const g=misBase(2),P=g.s.p,E=g.s.e;P.hand=[MU('a17',{ready:false})];P.front[2]=MU('a2');E.front[2]=MU('c1');TUT.d={}},
check(){if(G.turn!=='p'||G.busy){TUT.d.ended=1;return}if(!TUT.d.ended)return;if(G.rxk==='wire')return['ok','O Arame Farpado disparou: o atacante levou 2 de dano antes de golpear. Reações escondem a surpresa até o último momento.'];if(G.s.p.rx.some(Boolean))return['ok','A reação ficou armada, mas desta vez o inimigo não atacou. Ela continua escondida, esperando o próximo ataque.'];return['fl','Você encerrou o turno sem armar a reação. Reinicie, toque na carta e escolha uma casa ao lado do seu QG.']}},
sap:{ic:'🧱',t:'Sapador',s:'Salve o Mark IV de um ataque certeiro.',
x:'O caça inimigo vai atacar o Mark IV ferido. Mobilize o Sapador (custa 2), toque nele e depois no Mark IV para torná-lo imune ('+CFG.barCost+' de comando). Depois encerre o turno.',end:1,
setup(){const g=misBase(2+CFG.barCost),P=g.s.p,E=g.s.e;P.hand=[MU('a19',{ready:false})];const k=MU('a8',{hp:2});P.front[2]=k;E.rear[2]=MU('c10');TUT.d={k}},
check(){const k=TUT.d.k;if(k.imm)TUT.d.used=1;if(G.turn!=='p'||G.busy){TUT.d.ended=1;return}if(!TUT.d.ended)return;if(!G.s.p.front.includes(k))return['fl','O Mark IV caiu. Reinicie: mobilize o Sapador e imunize o Mark IV antes de encerrar o turno.'];if(TUT.d.used)return['ok','O Mark IV sobreviveu: a imunidade absorveu o ataque. Lembre que o escudo cai se o Sapador morrer, então proteja-o também.'];return['fl','O Mark IV sobreviveu, mas sem o escudo do Sapador. Reinicie e use a habilidade para praticar.']}}
};
