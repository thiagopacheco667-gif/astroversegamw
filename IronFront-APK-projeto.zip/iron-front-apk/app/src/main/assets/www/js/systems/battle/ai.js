/* Iron Front — systems/battle/ai.js
 * Inteligência artificial do inimigo e seu turno. Lógica original, sem alterações.
 */
import {G, diff} from '../../core/state.js';
import {sleep} from '../../core/util.js';
import {CARDS} from '../../data/cards.js';
import {CFG} from '../../data/config.js';
import {aaDmg, build, cmdOk, endTurnFx, hqDmg, ovOf, place, ranged, rowOf, setRx, startTurn, targets, unitDmg, useCmd, useOp} from './engine.js';
import {strike} from '../../ui/animation.js';
import {render} from '../../ui/render.js';

function aiBuild(){const S=G.s.e;if(S.cp<CFG.barCost)return false;const sp=S.front.find(u=>u&&u.ab==='build'&&u.ready&&!u.att);if(!sp)return false;if(diff==='easy'&&Math.random()>=.5)return false;let best=0,tr=null;for(const r of['front','rear'])S[r].forEach((u,i)=>{if(!u||u===sp||u.imm||u.cost<3)return;const sc=u.cost*2+u.atk+(CARDS[u.id].hp-u.hp)*2;if(sc>best){best=sc;tr={r,i}}});if(!tr)return false;build('e',sp,tr.r,tr.i);return true}
function aiCmd(pre){const S=G.s.e,P=G.s.p,c=S.cmd;if(diff==='easy'||!c||cmdOk('e'))return;const U=[...S.front,...S.rear],fr=S.front.filter(u=>u&&u.ready&&!u.att).length,z=U.filter(u=>u&&!u.ready&&!u.att).length;
const go={foch:pre&&fr>=2,haig:pre&&(S.hand.length<=5||U.some(u=>u&&u.hp<CARDS[u.id].hp)),pershing:pre&&S.hand.length>=4,ludendorff:!pre&&z>=1,hindenburg:pre,falkenhayn:pre&&P.front.filter(Boolean).length>=2}[c];if(go){useCmd('e');render();return true}return false}
function canUse(S,c){if(c.cat==='rx')return S.rx.includes(null);if(c.cat!=='ops')return S[rowOf(c)].includes(null);if(c.ab==='draw2')return S.hand.length<=CFG.hand-2;if(c.ab==='heal4')return S.hq<=CFG.hq-CFG.heal;return true}
function pick(o,cp){let best=0,bs=-1,n=o.length;for(let m=1;m<(1<<n);m++){let c=0,u=0;for(let i=0;i<n;i++)if(m>>i&1){c+=o[i].cost;if(o[i].cat!=='ops')u++}if(c>cp)continue;const v=c*10+u;if(v>bs){bs=v;best=m}}let r=null;for(let i=0;i<n;i++)if(best>>i&1&&(!r||o[i].cost>r.cost))r=o[i];return r||o[0]}
export async function aiTurn(){const gid=G.id,ok=()=>G&&G.id===gid;G.busy=true;const S=G.s.e,P=G.s.p;startTurn('e');render();await sleep(700);
try{if(!ok())return;if(aiCmd(true)){await sleep(1100);if(!ok())return}for(let b=0;b<CFG.barMax&&aiBuild();b++){render();await sleep(650);if(!ok())return}for(let k=0;k<12&&!G.over;k++){const o=S.hand.filter(c=>c.cost<=S.cp&&canUse(S,c));if(!o.length)break;
const c=diff==='easy'?o[Math.random()*o.length|0]:diff==='hard'?pick(o,S.cp):o.sort((a,b)=>b.cost-a.cost)[0];
if(c.cat==='rx'){setRx('e',c)}
else if(c.cat==='ops'){let t={row:'hq',i:0};if(c.ab==='dmg3'){const us=[];for(const r of['front','rear'])P[r].forEach((u,i)=>u&&us.push({row:r,i,u}));us.sort((a,b)=>(b.u.atk+b.u.cost)-(a.u.atk+a.u.cost));const kill=us.find(x=>x.u.hp<=ovOf('p',x.row,x.i,x.u,CFG.dmg));if(P.hq<=CFG.dmg)t={row:'hq',i:0};else if(kill)t=kill;else if(us.length&&diff!=='easy')t=us[0]}useOp('e',c,t)}
else{const r=rowOf(c),fr=S[r].map((u,i)=>u?-1:i).filter(i=>i>=0);const tr=r==='front'?fr.find(i=>S.tr[i]):undefined;place('e',c,tr!==undefined?tr:fr[0]);if(c.ab==='build')aiBuild()}
render();await sleep(550);if(!ok())return}
if(aiCmd(false)){await sleep(1100);if(!ok())return}for(const r of['front','rear'])for(let i=0;i<CFG.slots&&!G.over;i++){const u=S[r][i];if(!u||!u.ready||u.att||u.ab==='build')continue;if(diff==='hard'&&u.cat!=='air'&&P.rx.some(Boolean)&&Math.random()<.3)continue;const L=targets('e',u);if(!L.length)continue;let b;
if(diff==='easy')b=L[Math.random()*L.length|0];
else{let best=-99;for(const t of L){let s;if(t.row==='hq')s=hqDmg(u)>=P.hq?1000:hqDmg(u)*2+(P.hq<=8?4:0);else{if(t.t.imm){if(-50>best){best=-50;b=t}continue}const k=t.t.hp<=ovOf('p',t.row,t.i,t.t,unitDmg(u,t.t)),d=!ranged(u)&&t.t.cat!=='art'&&t.t.atk>=u.hp;s=(k?t.t.cost*2+t.t.atk+2:t.t.atk*.5)-(d?u.cost*2+u.atk:0)+(t.t.ab==='guard'?1:0)}if(u.cat==='air'&&aaDmg(u,'p')>=u.hp)s-=u.cost*2+u.atk+2;if(s>best){best=s;b=t}}if(best<-1)continue}
await strike('e',r,i,b.row,b.i);if(!ok())return;render();await sleep(380);if(!ok())return}
}finally{if(ok()){if(!G.over){endTurnFx('e');G.turn='p';startTurn('p')}G.busy=false;render()}}}
