/* Iron Front — systems/battle/engine.js
 * Regras da batalha: baralho, turnos, ataque, reações, comandantes, fortificação, vitória e derrota. Lógica original, sem alterações.
 */
import {G, TUT, diff, gidc, next_gidc, next_uid, pf, set_G, set_TUT, uid} from '../../core/state.js';
import {$, OPP, shuffle} from '../../core/util.js';
import {CARDS} from '../../data/cards.js';
import {CMDS, cmSel} from '../../data/commanders.js';
import {CDR, CFG, MOBAT, NAMES, RXD, RXK, SCHL, TAG} from '../../data/config.js';
import {DECKS} from '../../data/decks.js';
import {clearSave} from '../save/match.js';
import {SAVE, save} from '../save/profile.js';
import {NAMEUSE, fallen, mkSoldier, vet} from '../soldiers.js';
import {hideCoach, tutCheck} from '../tutorial/tutorial.js';
import {shakeB} from '../../ui/animation.js';
import {ambSync, dieSfx, newAttack, sfx, stopSfx, vib} from '../../ui/audio.js';
import {banner, fx, toast} from '../../ui/effects.js';
import {render} from '../../ui/render.js';
import {refreshRs, scr, stats} from '../../ui/screens.js';
import {say} from '../../ui/speech.js';

export const rowOf=c=>(c.cat==='inf'||c.cat==='arm')?'front':'rear';
export const ranged=c=>c.cat==='art'||c.cat==='air';
const mkDeck=p=>{const d=[];for(const[n,q]of Object.entries(DECKS[p]))for(let k=0;k<q;k++){const c={...CARDS[p+n],uid:next_uid(),ready:false,att:false,bt:0};c.sd=mkSoldier(c);d.push(c)}return shuffle(d)};
export const side=p=>({f:p,tn:0,hq:CFG.hq,cp:0,max:0,deck:mkDeck(p),hand:[],front:Array(CFG.slots).fill(null),rear:Array(CFG.slots).fill(null),rx:[null,null],tr:[0,0,0,0,0],cmd:null,cdr:0,nx:0});
export const log=m=>{G.log.unshift(m);G.log.length=Math.min(G.log.length,40)};
function draw(id,n){const S=G.s[id];for(let i=0;i<n;i++){if(!S.deck.length){S.hq-=CFG.fatigue;fx(id+'-hq','fl','-'+CFG.fatigue);log('Baralho vazio: QG perde '+CFG.fatigue);continue}const c=S.deck.pop();if(S.hand.length>=CFG.hand){log('Mão cheia: '+c.nm+' descartada');continue}S.hand.push(c);if(id==='p')sfx('draw',i*.09)}}
export const unitC=c=>!!c&&c.cat!=='ops'&&c.cat!=='rx';
const lsCnt=S=>S.hand.length+S.front.filter(Boolean).length+S.rear.filter(Boolean).length+S.rx.filter(Boolean).length;
function lsOn(id){const S=G.s[id];if(!S||S.tn<CFG.lsAt)return false;const m=lsCnt(S);return lsCnt(G.s[OPP(id)])-m>=CFG.lsDiff&&(m<=CFG.lsFew||S.hq<=CFG.lsHq)}
function lsStart(id){const S=G.s[id],was=!!S.ls;S.ls=lsOn(id)?1:0;S.lu=0;if(S.ls&&!was){log(G.names[id]+': ÚLTIMA CARTADA ativa');banner(id==='p'?'▶ ÚLTIMA CARTADA<br>Sua 1ª unidade de cada turno ataca ao entrar':'▶ O inimigo ativou a ÚLTIMA CARTADA<br>A 1ª unidade dele de cada turno ataca ao entrar',id==='p'?'ok':'bad')}}
export function goWhy(c){if(!unitC(c)||c.ab==='build')return 0;if(c.ab==='rush'||c.ab==='infil')return 1;if(G&&!G.over&&G.turn==='p'&&G.s&&G.s.p.hand.includes(c)){const S=G.s.p;if(S.f==='c'&&S.tn<=SCHL)return 2;if(S.ls&&!S.lu)return 3}return 0}
export function startTurn(id){const S=G.s[id];S.tn=(S.tn||0)+1;for(const r of['front','rear'])S[r].forEach(u=>{if(u)u.fr=0});const mob=S.f==='a'&&S.tn===MOBAT;S.max=Math.min(CFG.maxCp+(S.f==='a'&&S.tn>=MOBAT?1:0),S.max+1+(mob?1:0));S.cp=S.max+(S.nx||0)+(id==='e'&&S.tn===1?2:0);S.nx=0;if(S.cdr>0)S.cdr--;if(mob)log(G.names[id]+': Mobilização, +1 de comando');for(const r of['front','rear'])S[r].forEach(u=>{if(u){u.ready=true;u.att=false;u.imm=false;u.sho=0}});draw(id,S.tn>=CFG.drawAt?2:1);lsStart(id);if(id==='p')G.n++;win()}
export function win(){if(G.over)return;const p=G.s.p.hq<=0,e=G.s.e.hq<=0;if(p||e)finish(p&&e?'d':e)}
export function finish(won){if(TUT&&TUT.m){G.over=true;G.sel=null;sfx(won===true?'win':'lose');render();tutCheck();return}G.over=true;G.sel=null;if(!TUT){clearSave();if(won!=='d')won?SAVE.w++:SAVE.l++;save()}sfx(won===true?'win':'lose');if(won!=='d'){say('p',won?'w':'d',1);say('e',won?'d':'w',1)}const g0=G.id;setTimeout(()=>{if(!G||G.id===g0)stopSfx(.7)},2800);setTimeout(()=>{$('#msg').textContent=won==='d'?'EMPATE. Os dois QGs caíram juntos.':won?'VITÓRIA! O QG inimigo foi destruído.':'DERROTA. Seu QG caiu.';refreshRs();scr('home');$('#ov').hidden=false;stats()},900);render()}
export function why(a,tid,trow,ti){const T=G.s[tid],fr=T.front.filter(Boolean);if(a.ab==='build')return'Sapadores não atacam: eles tornam uma unidade imune.';if(a.cat==='air')return null;
if(trow==='front'){if(a.cat==='art'||a.ab==='infil')return null;const t=T.front[ti];return(fr.some(u=>u.ab==='guard'&&!u.imm)&&t.ab!=='guard')?'Há uma unidade com GUARDA: ataque-a primeiro.':null}
if(a.ab==='siege'&&trow==='rear')return null;return fr.length?(a.cat==='art'?'Artilharia só atinge a linha de frente enquanto houver unidades nela.':'A linha de frente inimiga bloqueia o avanço.'):null}
export function targets(aid,a){const tid=OPP(aid),T=G.s[tid],L=[];for(const r of['front','rear'])T[r].forEach((t,i)=>{if(t&&!why(a,tid,r,i))L.push({row:r,i,t})});if(!why(a,tid,'hq',0))L.push({row:'hq',i:0});return L}
function zOf(sd,u){for(const r of['front','rear']){const i=G.s[sd][r].indexOf(u);if(i>=0)return`${sd}-${r}-${i}`}return null}
function onDeath(id,r,i,u){const S=G.s[id],o=OPP(id);if(u.cai==='c_heal'){S.hq=Math.min(CFG.hq,S.hq+1);fx(id+'-hq','fl','+1');return false}
if(u.cai==='c_pos'){if(r==='front'){S.tr[i]=1;log('Trincheira aberta onde caiu '+u.nm);banner('⛏ TRINCHEIRA<br>'+u.nm+' caiu: a casa dá +1♥ à próxima unidade',id==='p'?'ok':'bad')}return false}
if(u.cai==='c_wreck'){const t=G.s[o].front[i];if(t&&!t.imm){t.hp-=1;fx(`${o}-front-${i}`,'boom');fx(`${o}-front-${i}`,'fl','-1');log('💥 '+u.nm+' explode: '+t.nm+' -1');banner('💥 '+u.nm.toUpperCase()+' EXPLODE<br>'+t.nm+' -1: '+(t.hp>0?'sobrevive com '+t.hp+'♥':'destruída'),o==='p'?'bad':'ok');G.pz=Math.max(G.pz||0,700);return true}return false}
if(u.cai==='c_rev'){const k=G.kl;if(k&&k.hp>0&&k.cat!=='air'){const z=zOf(o,k);if(z&&!k.imm){k.hp-=1;fx(z,'fl','-1');log('✦ '+u.nm+' fere '+k.nm+': -1');banner('✦ '+u.nm.toUpperCase()+' CAI<br>'+k.nm+' -1: '+(k.hp>0?'sobrevive com '+k.hp+'♥':'destruída'),o==='p'?'bad':'ok');G.pz=Math.max(G.pz||0,700);return true}}}return false}
function onEnter(id,c){const S=G.s[id],o=OPP(id);if(!c.ent)return;if(c.ent==='e_draw')draw(id,1);else if(c.ent==='e_cp')S.cp+=1;else if(c.ent==='e_hq1'){G.s[o].hq-=1;fx(o+'-hq','fl','-1');win()}log('✦ '+c.nm+': '+TAG[c.ent])}
function collapseBars(id,u){let n=0;for(const r of['front','rear'])G.s[id][r].forEach((t,j)=>{if(t&&t.imm&&t.sho===u.uid){t.imm=false;t.sho=0;n++;fx(`${id}-${r}-${j}`,'boom')}});if(n)log('🛡 Com a queda de '+u.nm+', a imunidade acaba')}
function sweep(d=0){const dead=[];for(const id of['p','e'])for(const r of['front','rear'])G.s[id][r].forEach((u,i)=>{if(u&&u.hp<=0){G.s[id][r][i]=null;fx(`${id}-${r}-${i}`,'boom');dieSfx();vib([80,40,120]);fallen(id,u);if(u.ab==='build')collapseBars(id,u);dead.push([id,r,i,u])}});let again=false;for(const[id,r,i,u]of dead)if(onDeath(id,r,i,u))again=true;if(again&&d<3)sweep(d+1)}
const wounded=u=>!!u&&u.hp<CARDS[u.id].hp;
export function ovOf(tid,row,i,u,d){return d>0&&u&&u.imm?0:d}
function soak(tid,row,i,u,d,z){let ov=d;if(d>0&&u&&u.imm){ov=0;fx(z,'spark');log('🛡 '+u.nm+' está imune: nenhum dano')}fx(z,'fl',ov?'-'+ov:'🛡');return ov}
export function buildWhy(S,row,i,sp){const t=S[row]&&S[row][i];if(!t)return'Toque numa unidade sua para torná-la imune.';if(t===sp)return'O Sapador não protege a si mesmo.';if(t.imm)return'Esta unidade já está imune.';if(S.cp<CFG.barCost)return'Proteger custa '+CFG.barCost+' de comando.';return''}
export const buildHint=(S,sp)=>S.cp<CFG.barCost?'Proteger custa '+CFG.barCost+' de comando.':'Toque numa unidade sua (frente ou retaguarda) marcada com + para torná-la IMUNE até o seu próximo turno (custa '+CFG.barCost+' de comando).';
export function build(id,u,row,i){const S=G.s[id],t=S[row][i];t.imm=true;t.sho=u.uid;S.cp-=CFG.barCost;u.att=true;u.ready=false;fx(`${id}-${row}-${i}`,'spark');sfx('place');log(G.names[id]+': '+u.nm+' torna '+t.nm+' imune até o próximo turno ('+(row==='front'?'frente':'retaguarda')+', casa '+(i+1)+')');if(id==='p'){vib(18);toast('🛡 '+t.nm+' imune até o seu próximo turno.')}else banner('🛡 IMUNIDADE<br>O inimigo protegeu '+t.nm,'bad')}
export const hqDmg=a=>a.cat==='air'?Math.max(1,a.atk-CFG.airHq):a.atk;
export const unitDmg=(a,t)=>a.cat==='inf'&&t.ab==='armor'?Math.max(1,a.atk-1):a.atk;
export const aaDmg=(a,tid)=>a.cat==='air'&&G.s[tid].front.some(u=>u&&u.ab==='guard'&&!u.imm)?CFG.aa:0;
export function attack(aid,arow,ai,trow,ti){const tid=OPP(aid),A=G.s[aid],T=G.s[tid],a=A[arow][ai],za=`${aid}-${arow}-${ai}`,zt=trow==='hq'?tid+'-hq':`${tid}-${trow}-${ti}`,aa=aaDmg(a,tid);
if(fireRx(tid,a,za)&&(a.hp<=0||G.rxk==='mine')){a.att=true;a.ready=false;sweep();win();return}
const d=(trow==='hq'?hqDmg(a):unitDmg(a,T[trow][ti]))+(a.ab==='rush'&&a.fr?1:0);
fx(za,'shk');fx(zt,'shk');fx(zt,'spark');
if(trow==='hq'){fx(zt,'fl','-'+d);T.hq-=d;log(a.nm+' atinge o QG: -'+d)}
else{const t=T[trow][ti],ov=soak(tid,trow,ti,t,d,zt);t.hp-=ov;let m=a.nm+' → '+t.nm;if(!ranged(a)&&t.cat!=='art'&&t.atk>0&&a.ab!=='infil'){const cd=a.ab==='armor'&&t.cat==='inf'?Math.max(1,t.atk-1):t.atk;if(a.imm){fx(za,'fl','🛡');m+=' (contra-ataque anulado: imune)'}else{a.hp-=cd;fx(za,'fl','-'+cd);m+=' (contra-ataque '+cd+')'}}log(m);
if(a.ab==='barrage')for(const j of[ti-1,ti+1]){const n=j>=0&&j<CFG.slots&&T[trow][j];if(n){n.hp-=soak(tid,trow,j,n,1,`${tid}-${trow}-${j}`)}}}
if(aa&&!a.imm){a.hp-=aa;fx(za,'fl','-'+aa);log('Fogo antiaéreo atinge '+a.nm+': -'+aa)}
a.att=true;a.ready=false;G.kl=a;sweep();G.kl=null;vet(a,za);if(trow!=='hq')vet(T[trow][ti],zt);win()}
function fireRx(tid,a,za){const S=G.s[tid],i=S.rx.findIndex(c=>c&&RXK[c.ab]===a.cat);if(i<0)return false;const c=S.rx[i];S.rx[i]=null;const d=RXD[c.ab];G.rxk=c.ab;const d0=a.imm?0:d;a.hp-=d0;const res=a.hp>0?'sobrevive com '+a.hp+'♥'+(c.ab==='mine'?' — ataque cancelado':''):'destruída — ataque cancelado',g=document.getElementById('ghost');if(g){g.classList.add('rxg');g.insertAdjacentHTML('beforeend','<span class="boom"></span><span class="fl">-'+d0+'</span>');setTimeout(()=>g.classList.remove('rxg'),1200)}else{fx(za,'boom');fx(za,'fl','-'+d0)}
log('⚡ '+c.nm+' atinge '+a.nm+': -'+d0+' ('+res+')');banner('⚡ '+c.nm.toUpperCase()+'<br>'+a.nm+' -'+d0+': '+res,tid==='p'?'ok':'bad');G.pz=900;say(tid,'r',1);sfx('boomS');vib([40,20,60]);return true}
export function setRx(id,c){const S=G.s[id],i=S.rx.indexOf(null);if(i<0){if(id==='p')toast('Suas 2 casas de reação estão ocupadas.');return false}S.rx[i]=c;S.cp-=c.cost;S.hand.splice(S.hand.indexOf(c),1);sfx('card');log(G.names[id]+' arma uma reação');if(id==='p')vib(12);return true}
export function cmdOk(id){const S=G.s[id],C=CMDS[S.cmd];if(!C)return'';if(S.cdr>0)return'Comandante em preparo: '+S.cdr+' turno(s).';if(S.cp<C.c)return'Comando insuficiente (custa '+C.c+').';if(S.cmd==='hindenburg'&&!(S.hand.some(c=>c.cat==='rx')&&S.rx.includes(null)))return'Precisa de uma reação na mão e de uma casa livre.';return''}
export function endTurnFx(id){for(const r of['front','rear'])G.s[id][r].forEach(u=>{if(u&&u.tmp){u.atk-=u.tmp;u.tmp=0}})}
export function useCmd(id){const S=G.s[id],C=CMDS[S.cmd],o=OPP(id),T=G.s[o],K=S.cmd;S.cp-=C.c;S.cdr=CDR;newAttack();sfx('star');log('★ '+C.n+': '+C.t.split(':')[0]);banner('★ '+C.n.toUpperCase()+'<br>'+C.t,id==='p'?'ok':'bad');say(id,'o',1);vib(25);
if(K==='foch')S.front.forEach((u,i)=>{if(u){u.atk+=1;u.tmp=(u.tmp||0)+1;fx(`${id}-front-${i}`,'fl','+1 ⚔')}});
else if(K==='haig'){draw(id,1);for(const r of['front','rear'])S[r].forEach((u,i)=>{if(u&&u.hp<CARDS[u.id].hp){u.hp++;fx(`${id}-${r}-${i}`,'fl','+1')}})}
else if(K==='pershing')S.nx=2;
else if(K==='ludendorff')[...S.front,...S.rear].forEach(u=>{if(u&&!u.ready&&!u.att)u.ready=true});
else if(K==='hindenburg'){const c=S.hand.find(c=>c.cat==='rx'),i=S.rx.indexOf(null);S.rx[i]=c;S.hand.splice(S.hand.indexOf(c),1);sfx('card')}
else if(K==='falkenhayn'){T.front.forEach((u,i)=>{if(u&&!u.imm){u.hp-=1;fx(`${o}-front-${i}`,'boom');fx(`${o}-front-${i}`,'fl','-1')}});sfx('boomM');shakeB();sweep();win()}}
export function place(id,c,i){const S=G.s[id];S[rowOf(c)][i]=c;c.fr=1;c.ready=c.ab==='build'||c.ab==='rush'||c.ab==='infil'||(S.f==='c'&&S.tn<=SCHL);if(!c.ready&&S.ls&&!S.lu&&unitC(c)&&c.ab!=='build'){c.ready=true;S.lu=1;log('▶ Última cartada: '+c.nm+' ataca ao entrar');if(id==='p')banner('▶ ÚLTIMA CARTADA<br>'+c.nm+' ataca ao entrar','ok')}c.att=false;S.cp-=c.cost;S.hand.splice(S.hand.indexOf(c),1);fx(`${id}-${rowOf(c)}-${i}`,'pop');sfx('place');if(id==='p')vib(12);if(rowOf(c)==='front'&&S.tr[i]){S.tr[i]=0;c.hp+=1;log('Trincheira: '+c.nm+' entra com +1 de vida')}log(G.names[id]+' mobiliza '+c.nm);onEnter(id,c)}
export function useOp(id,c,tg){const S=G.s[id],o=OPP(id),T=G.s[o];S.cp-=c.cost;S.hand.splice(S.hand.indexOf(c),1);newAttack();sfx('op');log(G.names[id]+' usa '+c.nm);
if(c.ab==='dmg3'){const z=tg.row==='hq'?o+'-hq':`${o}-${tg.row}-${tg.i}`;if(tg.row==='hq'){T.hq-=CFG.dmg;fx(z,'fl','-'+CFG.dmg)}else{const t=T[tg.row][tg.i];t.hp-=soak(o,tg.row,tg.i,t,CFG.dmg,z)}fx(z,'boom');sfx('whistle');sfx('boomM',.3);vib([60,30,90]);shakeB()}
else if(c.ab==='draw2')draw(id,2);
else{S.hq=Math.min(CFG.hq,S.hq+CFG.heal);fx(id+'-hq','fl','+'+CFG.heal)}
sweep();win()}
export function riskOf(a,tid,row,i){const t=G.s[tid][row][i];if(!t||ranged(a)||t.cat==='art'||!(t.atk>0)||a.ab==='infil')return null;const cd=a.ab==='armor'&&t.cat==='inf'?Math.max(1,t.atk-1):t.atk,d=unitDmg(a,t)+(a.ab==='rush'&&a.fr?1:0),td=t.hp<=ovOf(tid,row,i,t,d),ad=!a.imm&&a.hp<=cd;if(a.imm)return null;return ad?td?[3,'☠ TROCA']:[2,'☠ MORRE']:[1,'↩ -'+cd]}
export const hasCtr=c=>!!c&&c.cat!=='art'&&c.cat!=='ops'&&c.cat!=='rx'&&c.atk>0;
export function start(){setTimeout(()=>{if(G&&!G.over&&!TUT){say('p','i',1);setTimeout(()=>say('e','i',1),1800)}},700);stopSfx(.05);NAMEUSE.clear();ambSync();set_TUT(null);hideCoach();const ef=pf==='a'?'c':'a';set_G({id:next_gidc(),s:{p:side(pf),e:side(ef)},turn:'p',busy:false,over:false,sel:null,detail:null,log:['Batalha iniciada.'],n:0,names:{p:NAMES[pf],e:NAMES[ef]}});for(const k of['p','e']){const Q=G.s[k];Q.max=1;const ch=Q.deck.filter(c=>c.cat!=='ops'&&c.cat!=='rx'&&c.ab!=='build'&&c.cost<=2).slice(0,2);Q.deck=Q.deck.filter(c=>!ch.includes(c)).concat(ch)}if(diff==='hard')G.s.e.max=2;G.s.p.cmd=cmSel[pf];{const el=Object.keys(CMDS).filter(k=>CMDS[k].f===ef);G.s.e.cmd=el[Math.random()*el.length|0]}draw('p',CFG.startP);draw('e',CFG.startE);startTurn('p');$('#ov').hidden=true;$('#rs').hidden=true;render()}
