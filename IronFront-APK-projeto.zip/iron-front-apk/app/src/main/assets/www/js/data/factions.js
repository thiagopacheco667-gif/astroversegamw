/* Iron Front — data/factions.js
 * Dados declarativos: facções (Aliados e Potências Centrais).
 */
import {CFG, MOBAT, SCHL} from './config.js';

export const FACT={a:{pt:'MOBILIZAÇÃO: a partir do seu '+MOBAT+'º turno você ganha +1 de comando e o teto de comando sobe para '+(CFG.maxCp+1)+'.',sum:'Aliados · desgaste e escala. Mobilização: +1 de comando e teto '+(CFG.maxCp+1)+' a partir do '+MOBAT+'º turno. Mais blindados (COURAÇA) e obus com BARRAGEM.'},c:{pt:'PLANO SCHLIEFFEN: nos seus '+SCHL+' primeiros turnos, suas unidades entram prontas para agir.',sum:'Potências Centrais · ofensiva rápida. Plano Schlieffen: nos '+SCHL+' primeiros turnos as unidades entram prontas. Stoßtruppen com INFILTRAÇÃO e Grande Berta com CERCO.'}};
export const FH={a:'França, Império Britânico e Estados Unidos: a força industrial e as reservas humanas que, no longo prazo, venceram a guerra de desgaste.',c:'Alemanha e Áustria-Hungria: o exército mais profissional de 1914, que apostava em ofensivas rápidas e em inovações táticas, como as tropas de assalto.'};
