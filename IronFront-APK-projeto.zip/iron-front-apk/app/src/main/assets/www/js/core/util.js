/* Iron Front — core/util.js
 * Utilitários puros compartilhados (seletor, espera, sorteio, escape de HTML, PRNG semeado).
 */
export const $=s=>document.querySelector(s);
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export const OPP=i=>i==='p'?'e':'p';
export const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
export const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
export const rnd=seed=>{let t=seed+0x6D2B79F5|0;return()=>{t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}};
