/* Iron Front — ui/render.js
 * Renderização do tabuleiro, mão, QG, painéis e HTML das cartas.
 */
import {G} from '../core/state.js';
import {$} from '../core/util.js';
import {CARDS} from '../data/cards.js';
import {CMDS} from '../data/commanders.js';
import {CATN, CDR, CFG, NAMES, TAG} from '../data/config.js';
import {FACT} from '../data/factions.js';
import {ABD, CTR} from '../data/glossary.js';
import {HQI, IMG, PIC} from '../data/images.js';
import {buildWhy, cmdOk, goWhy, hasCtr, riskOf, rowOf, targets} from '../systems/battle/engine.js';
import {persist} from '../systems/save/match.js';
import {soldierInfo, stars} from '../systems/soldiers.js';
import {tutCheck} from '../systems/tutorial/tutorial.js';
import {LIFT, Z} from './animation.js';
import {FX, set_FX} from './effects.js';
import {say} from './speech.js';

function cmdInfo(){const S=G.s.p,C=CMDS[S.cmd],w=cmdOk('p');return`<b>★ ${C.n}</b><br>Custo ${C.c} · recarga ${CDR} turnos<br>${C.t}<br><i>${w||'Toque de novo no botão para ordenar.'}</i>`}
function cardInfo(d){const u=d.cat!=='ops'&&d.cat!=='rx';return`<b>${d.nm}</b><br>${d.nat} · ${CATN[d.cat]}<br>Custo ${d.cost}${u?` · ⚔${d.atk} ♥${d.hp}/${CARDS[d.id].hp}`:''}<br>${ABD[d.ab]||(d.ent||d.cai?'':'Sem habilidade.')}${d.ent?'<br>'+ABD[d.ent]:''}${d.cai?'<br>'+ABD[d.cai]:''}${d.imm?'<br><b>🛡 IMUNE até o próximo turno do dono.</b>':''}${hasCtr(d)?'<br>'+CTR:''}${u?soldierInfo(d):''}<br><i class="tx">${d.tx}</i>`}
let LHQ=null;
function art(c){if(IMG[c.id])return '<img src="'+IMG[c.id]+'" alt="" draggable="false">';const n=+c.id.slice(1),a=c.id[0]==='a',K=a?'#6b6a3a':'#5d6266',D='#222';let s='';
const H={b:'<path d="M22 13q8-12 16 0z" fill="#6b6a3a"/><rect x="21" y="12.5" width="18" height="2" fill="#555"/>',f:'<path d="M24 13q6-11 12 0z" fill="#3b5a8a"/><rect x="29" y="4" width="2" height="4" fill="#3b5a8a"/>',g:'<path d="M24 13q6-10 12 0l3 5h-4l-10-1z" fill="#4a4f52"/>',o:'<rect x="25" y="5" width="10" height="7" rx="2" fill="#8a2a2a"/>',k:'<path d="M23 12h14l-2-5h-10z" fill="#5d6266"/><path d="M36 8l5-5" stroke="#2a6a3a" stroke-width="2"/>',u:'<path d="M23 13q7-10 14 0z" fill="#7a7a40"/>'};
if(c.cat==='inf'){if(c.ab==='build')s='<circle cx="30" cy="13" r="5" fill="#d9b48f"/>'+(a?H.b:H.g)+'<rect x="25" y="18" width="10" height="14" rx="2" fill="'+K+'"/><path d="M37 24L48 9" stroke="#5a4a30" stroke-width="2"/><path d="M46 5l6 2-2 6-6-2z" fill="#8a8a8a" stroke="#222" stroke-width=".8"/><g fill="#b8a574" stroke="#6b5a35" stroke-width=".8"><rect x="10" y="29" width="14" height="6" rx="3"/><rect x="23" y="29" width="14" height="6" rx="3"/><rect x="36" y="29" width="14" height="6" rx="3"/><rect x="16.5" y="23.5" width="14" height="6" rx="3"/><rect x="29.5" y="23.5" width="14" height="6" rx="3"/></g>';else if(c.ab==='guard')s='<path d="M6 30h48v8H6z" fill="#8a7a55"/><rect x="18" y="20" width="22" height="4" fill="#222"/><rect x="38" y="19" width="12" height="2" fill="#222"/><path d="M24 24l-6 12M30 24l2 12M34 24l8 12" stroke="#222" stroke-width="2"/><circle cx="12" cy="24" r="4" fill="#d9b48f"/>'+(a?H.b:H.g).replace(/(\d+(\.\d+)?)(?=[ qlzMh])/,'$1').replace('<path d="M','<path transform="translate(-18 11)" d="M').replace('<rect x="21"','<rect transform="translate(-18 11)" x="21"');
else{const hk={a1:'b',a2:'f',a4:'f',a5:'u',c1:'g',c2:'o',c4:'g',c5:'k',c9:'o'}[c.id];s='<circle cx="30" cy="13" r="5" fill="#d9b48f"/>'+H[hk]+'<rect x="25" y="18" width="10" height="14" rx="2" fill="'+K+'"/><rect x="25" y="32" width="4" height="6" fill="'+D+'"/><rect x="31" y="32" width="4" height="6" fill="'+D+'"/><path d="M36 22L49 12" stroke="'+D+'" stroke-width="2"/>'+(c.ab==='rush'?'<circle cx="19" cy="22" r="3" fill="#333"/><rect x="18" y="17" width="2" height="3" fill="#333"/>':'')}}
else if(c.cat==='art'){const h=c.cost>=5;s='<circle cx="22" cy="31" r="'+(h?8:6)+'" fill="none" stroke="#222" stroke-width="3"/><path d="M20 27L'+(h?52:48)+' '+(h?8:12)+'" stroke="#333" stroke-width="'+(h?8:5)+'" stroke-linecap="round"/><rect x="14" y="27" width="14" height="5" fill="'+K+'"/><circle cx="'+(h?54:50)+'" cy="'+(h?6:10)+'" r="4" fill="#eee" opacity=".8"/>'}
else if(c.cat==='arm'){s=a?(n===8?'<path d="M8 34l10-18h24l10 18z" fill="'+K+'" stroke="#222"/><rect x="12" y="31" width="40" height="5" rx="2.5" fill="#333"/><rect x="40" y="22" width="12" height="3" fill="#222"/>':'<rect x="14" y="26" width="32" height="6" fill="'+K+'"/><rect x="24" y="17" width="12" height="9" rx="3" fill="'+K+'"/><rect x="36" y="20" width="12" height="2.5" fill="#222"/><rect x="10" y="31" width="40" height="6" rx="3" fill="#333"/>'):'<rect x="10" y="16" width="38" height="16" fill="'+K+'" stroke="#222"/><rect x="40" y="12" width="9" height="8" fill="'+K+'" stroke="#222"/><rect x="48" y="20" width="8" height="2" fill="#222"/><rect x="8" y="31" width="42" height="6" rx="3" fill="#333"/>'}
else if(c.cat==='air'){const w=c.id==='c10'?3:2;s='<g fill="'+K+'"><ellipse cx="30" cy="22" rx="19" ry="3.5"/><path d="M11 21l-6-7v8z"/></g>';for(let k=0;k<w;k++)s+='<rect x="22" y="'+((w===3?9:13)+k*5)+'" width="18" height="2.5" rx="1" fill="'+K+'" stroke="#222" stroke-width=".5"/>';s+='<circle cx="28" cy="22" r="2" fill="'+(a?'#2a4a9a':'#111')+'"/><rect x="50" y="17" width="1.5" height="10" fill="#222"/>'+(n===11?'<circle cx="34" cy="18" r="2.5" fill="#d9b48f"/>':'')}
else if(c.ab==='dmg3')s='<circle cx="30" cy="24" r="12" fill="#e8892b"/><circle cx="30" cy="24" r="7" fill="#ffd96a"/><path d="M30 6l3 8-3 2-3-2zM12 14l9 5M48 14l-9 5" stroke="#c4472f" stroke-width="2.5"/>';
else if(c.ab==='draw2'){for(let k=0;k<3;k++)s+='<circle cx="'+(14+k*16)+'" cy="16" r="4" fill="#d9b48f"/><rect x="'+(10+k*16)+'" y="20" width="8" height="14" fill="'+K+'"/><path d="M'+(19+k*16)+' 20l5-6" stroke="#222" stroke-width="2"/>'}
else if(c.ab==='mine')s='<ellipse cx="30" cy="32" rx="17" ry="4" fill="#4a3a28"/><circle cx="23" cy="28" r="5" fill="#555" stroke="#222"/><circle cx="38" cy="29" r="4" fill="#555" stroke="#222"/><path d="M23 23v-3M38 25v-3" stroke="#c4472f" stroke-width="2"/>';
else if(c.ab==='counter')s='<circle cx="30" cy="22" r="13" fill="none" stroke="#c4472f" stroke-width="2.5"/><path d="M30 6v32M14 22h32" stroke="#c4472f" stroke-width="2"/><circle cx="30" cy="22" r="3" fill="#c4472f"/>';
else if(c.ab==='aa')s='<rect x="18" y="30" width="24" height="6" fill="#333"/><path d="M30 30L42 10" stroke="#222" stroke-width="4" stroke-linecap="round"/><circle cx="44" cy="8" r="2" fill="#e0a030"/><path d="M10 12q4-6 10 0" fill="none" stroke="#c4472f" stroke-width="2"/>';
else if(c.ab==='wire'){s='<path d="M4 34h52" stroke="#333" stroke-width="2"/>';for(let k=0;k<6;k++)s+='<path d="M'+(8+k*9)+' 20v16M'+(4+k*9)+' 24l8 8M'+(12+k*9)+' 24l-8 8" stroke="#222" stroke-width="1.5"/>';s+='<path d="M4 24q13-6 26 0t26 0" fill="none" stroke="#555" stroke-width="1.5"/>'}
else s='<rect x="16" y="10" width="28" height="24" fill="#c9b27a" stroke="#6b5a35" stroke-width="2"/><rect x="27" y="14" width="6" height="16" fill="#b33"/><rect x="22" y="19" width="16" height="6" fill="#b33"/>';
return '<svg viewBox="0 0 60 40" aria-hidden="true"><path d="M0 28l8-5 8 3 10-6 10 4 12-3 12 3v8H0z" fill="#0003"/><path d="M4 28v-5M10 28v-5M3 25h9" stroke="#0005" stroke-width=".8"/><ellipse cx="30" cy="38" rx="21" ry="2" fill="#0006"/>'+s+'</svg>'}
export function cardHTML(c,x=''){const op=c.cat==='ops'||c.cat==='rx';return`<div class="c ${c.cat} n${c.id[0]} ${x}" style="--r:${((c.uid||0)*37%21-10)/9}deg"><b class="cost">${c.cost}</b>${goWhy(c)?'<i class="go"></i>':''}${stars(c)?`<span class="vt">${'★'.repeat(stars(c))}</span>`:''}<span class="nm">${c.sn||c.nm}</span><i class="im">${art(c)}</i>${(c.ab||c.ent||c.cai)?`<em class="tg">${TAG[c.ab||c.ent||c.cai]}${c.ab&&(c.ent||c.cai)?' ✦':''}</em>`:''}<div class="st">${op?'<span>'+(c.cat==='rx'?'REAÇÃO':'OPS')+'</span><span></span>':`<span class="a">⚔${c.atk}</span><span class="h">♥${c.hp}</span>`}</div></div>`}
const barAttr=(id,r,i)=>{const u=G.s[id][r][i];return u&&u.imm?' data-bar="🛡 IMUNE"':''}
export function render(){if(!G)return;const S=G.s,sel=G.sel,tg=new Set(),RK={};if(LHQ&&LHQ.g===G.id){for(const k of['p','e'])if(S[k].hq<LHQ[k])say(k,'h')}LHQ={g:G.id,p:S.p.hq,e:S.e.hq};
if(sel&&sel.kind==='unit')targets('p',sel.c).forEach(t=>{tg.add(t.row==='hq'?'e-hq':`e-${t.row}-${t.i}`);if(t.row!=='hq'){const k=riskOf(sel.c,'e',t.row,t.i);if(k)RK[`e-${t.row}-${t.i}`]=k}});
if(sel&&sel.kind==='hand'&&sel.c.ab==='dmg3'){['front','rear'].forEach(r=>S.e[r].forEach((u,i)=>u&&tg.add(`e-${r}-${i}`)));tg.add('e-hq')}
$('#B').innerHTML=[['e','rear'],['e','front'],['p','front'],['p','rear']].map(([id,r])=>`<div class="row ${id==='p'?'mine':'foe'}">`+S[id][r].map((u,i)=>{const z=`${id}-${r}-${i}`;let cl='cell'+(tg.has(z)?' tgt':'');if(r==='front'&&!u&&S[id].tr&&S[id].tr[i])cl+=' tr';
if(!u&&sel&&sel.kind==='hand'&&sel.c.cat!=='ops'&&sel.c.cat!=='rx'&&id==='p'&&rowOf(sel.c)===r)cl+=' slot';
if(sel&&sel.kind==='unit'&&sel.c.ab==='build'&&id==='p'&&u&&!buildWhy(S.p,r,i,sel.c))cl+=' bslot';
let h='';if(u){let x='';if(id==='p'){x=u.att?'dn':u.ready?'rdy':'zz';if(sel&&sel.c===u)x+=' sel'}h=cardHTML(u,x)}
return`<div class="${cl}" data-z="${z}" data-l="${r==='front'?'FRENTE':'RETAGUARDA'}"${barAttr(id,r,i)}>${h}${RK[z]?`<i class="rk r${RK[z][0]}">${RK[z][1]}</i>`:''}</div>`}).join('')+'</div>').join('');
const hq=id=>`<div class="hq ${id==='e'?'foe':'mine'}${tg.has(id+'-hq')?' tgt':''}" data-z="${id}-hq" style="background-image:linear-gradient(#0005,#0008),url(${HQI[G.names[id]===NAMES.a?'a':'c']})">${PIC[S[id].cmd]?`<img class="gp" alt="" src="${PIC[S[id].cmd]}">`:''}<small>QG · ${G.names[id]}</small><b>${Math.max(0,S[id].hq)}</b><small>Baralho ${S[id].deck.length} · Mão ${S[id].hand.length}</small><small class="rxs">⚡ Reações ${S[id].rx.filter(Boolean).length}/2</small></div>`;
$('#L').innerHTML=hq('e')+hq('p');
$('#H').innerHTML=S.p.hand.map((c,i)=>`<div class="hc" data-z="p-hand-${i}" style="transform:rotate(${((i-(S.p.hand.length-1)/2)*2.2).toFixed(1)}deg) translateY(${(Math.abs(i-(S.p.hand.length-1)/2)*1.6).toFixed(1)}px);transform-origin:50% 130%">${cardHTML(c,(sel&&sel.c===c?'sel ':'')+(c.cost>S.p.cp?'no':''))}</div>`).join('');
{const H=$('#H'),n=S.p.hand.length;if(n>1){const ov=Math.max(0,Math.ceil((n*70+(n-1)*3-H.clientWidth)/(n-1)));for(let i=1;i<n;i++)H.children[i].style.marginLeft=(-ov)+'px'}}
$('#info').innerHTML=`<b>${G.turn==='p'?'Seu turno':'Turno inimigo'}</b> · nº ${G.n}<br>Comando: <b>${S.p.cp}/${S.p.max}</b>${S.p.ls&&!S.p.lu&&G.turn==='p'?'<br>▶ <b>Última cartada</b>':''}`;
$('#end').disabled=G.turn!=='p'||G.busy||G.over;
{const b=$('#cmd'),C=CMDS[S.p.cmd];b.hidden=!C;if(C){b.textContent='★ '+C.n+' · '+(S.p.cdr>0?'⏳ '+S.p.cdr:C.c+' ⚡');b.classList.toggle('no',!!cmdOk('p')||G.turn!=='p'||G.busy)}}
const d=G.detail;$('#det').innerHTML=d&&d.cmd&&CMDS[S.p.cmd]?cmdInfo():d&&d.hq?hqInfo(d.hq):d?cardInfo(d):'Toque numa carta para ver os detalhes.';
$('#log').innerHTML=G.log.slice(0,4).map(l=>'• '+l).join('<br>');
for(const f of FX){const el=document.querySelector(`[data-z="${f.z}"]`);if(!el)continue;
if(f.t==='fl'||f.t==='boom'||f.t==='spark'){const s=document.createElement('span');s.className=f.t;if(f.x)s.textContent=f.x;el.appendChild(s);setTimeout(()=>s.remove(),950)}
else if(f.t==='pop'){const c=el.firstElementChild;c&&c.classList.add('pop')}
else{const c=el.firstElementChild||el;c.classList.add('shk');setTimeout(()=>c.classList.remove('shk'),350)}}
set_FX([]);if(LIFT){const e=Z(LIFT);if(e)e.classList.add('lifted')}persist();tutCheck()}
function hqInfo(id){const S=G.s[id];return`<b>QG · ${G.names[id]}</b><br>Resistência ${Math.max(0,S.hq)}/${CFG.hq}<br>${FACT[S.f].pt}<br>${S.ls&&!S.lu?'▶ ÚLTIMA CARTADA ativa: a 1ª unidade mobilizada no turno ataca ao entrar.<br>':''}${S.cmd?'★ Comandante: '+CMDS[S.cmd].n+'<br>':''}⚡ Reações: ${id==='p'?(S.rx.filter(Boolean).map(c=>c.nm).join(', ')||'nenhuma'):S.rx.filter(Boolean).length+' oculta(s)'}`}
