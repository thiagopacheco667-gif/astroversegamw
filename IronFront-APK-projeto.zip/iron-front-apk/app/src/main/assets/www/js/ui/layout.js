/* Iron Front — ui/layout.js
 * Escala do palco 800×360 para a tela do aparelho.
 */
import {app} from './input.js';

function fit(){const cs=getComputedStyle(document.documentElement),pl=parseFloat(cs.paddingLeft)||0,pr=parseFloat(cs.paddingRight)||0,pt=parseFloat(cs.paddingTop)||0,pb=parseFloat(cs.paddingBottom)||0;const w=innerWidth-pl-pr,h=innerHeight-pt-pb;let s=h/360,W=w/s;if(W<760){s=w/760;W=760}app.style.width=W+'px';app.style.height=(h/s)+'px';app.style.left=pl+'px';app.style.top=pt+'px';app.style.transform='scale('+s+')';document.documentElement.style.setProperty('--s',s)}
addEventListener('resize',fit);
addEventListener('orientationchange',fit);
if(window.visualViewport)visualViewport.addEventListener('resize',fit);
fit();
