/* Iron Front — ui/animation.js
 * Animações do ataque e do arrastar cartas (ghost, projétil, tremor).
 */
import {G} from '../core/state.js';
import {$, OPP, sleep} from '../core/util.js';
import {attack} from '../systems/battle/engine.js';
import {newAttack, sfxFire, sfxFlight, sfxImpact, vib} from './audio.js';
import {render} from './render.js';

export let STRK=false;
export let LIFT=null;
export const Z=z=>document.querySelector(`[data-z="${z}"]`);
const ctr=e=>{const r=e.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2}};
export const SC=()=>parseFloat(document.documentElement.style.getPropertyValue('--s'))||1;
const RM=()=>document.body.classList.contains('rm')||matchMedia('(prefers-reduced-motion:reduce)').matches;
export function shakeB(){if(RM())return;const b=$('#B');b.classList.remove('bshk');void b.offsetWidth;b.classList.add('bshk')}
export const unlift=()=>{LIFT=null;document.querySelectorAll('.lifted').forEach(x=>x.classList.remove('lifted'))};
const trf=(x,y,k)=>`translate(${x}px,${y}px) scale(${SC()*k})`;
export function setG(o,x,y,k){o.x=x;o.y=y;o.k=k;o.el.style.transform=trf(x,y,k)}
function atC(o,cx,cy,k){const s=SC();return{x:cx-o.w*s*k/2,y:cy-o.h*s*k/2,k}}
export function mkGhost(z,px,py,k,oy){const el=Z(z);if(!el)return null;const s=SC(),w=el.offsetWidth,h=el.offsetHeight,hand=/-hand-/.test(z),g=document.createElement('div');g.id='ghost';g.className=hand?'gh':'gb';g.style.width=w+'px';g.style.height=h+'px';
g.innerHTML=hand?el.innerHTML:`<div class="${z[0]==='e'?'foe':'mine'}"><div class="cell">${el.innerHTML}</div></div>`;document.body.appendChild(g);
const o={el:g,w,h,z,oy,x:0,y:0,k};setG(o,px-w*s*k/2,py-h*s*k*oy,k);return o}
async function mvG(o,x,y,k,ms,ease){if(!o||!o.el.isConnected)return;const a=o.el.animate([{transform:trf(o.x,o.y,o.k)},{transform:trf(x,y,k)}],{duration:ms,easing:ease||'ease-out',fill:'forwards'});try{await a.finished}catch(e){}setG(o,x,y,k);try{a.cancel()}catch(e){}}
const killG=o=>{if(o&&o.el)o.el.remove()};
export async function fadeG(o,ms=130){if(!o)return;try{await o.el.animate([{opacity:1},{opacity:0}],{duration:ms,fill:'forwards'}).finished}catch(e){}killG(o)}
export async function backG(o,z){if(!o){unlift();return}const e=z&&Z(z);if(e&&!RM()){const c=ctr(e),p=atC(o,c.x,c.y,1);await mvG(o,p.x,p.y,1,170)}unlift();killG(o)}
export async function settleG(o,z){unlift();if(!o)return;const e=Z(z);if(e&&!RM()){const c=ctr(e),p=atC(o,c.x,c.y,.85);await mvG(o,p.x,p.y,.85,110)}await fadeG(o,90)}
function shellFly(a,b,ms){const s=SC(),e=document.createElement('div');e.className='shell';document.body.appendChild(e);const d=Math.hypot(b.x-a.x,b.y-a.y),pk=Math.min(70*s,d*.35),fr=[];for(let i=0;i<=8;i++){const t=i/8;fr.push({transform:`translate(${a.x+(b.x-a.x)*t}px,${a.y+(b.y-a.y)*t-4*pk*t*(1-t)}px)`})}
return e.animate(fr,{duration:ms,easing:'linear'}).finished.catch(()=>{}).then(()=>e.remove())}
export async function strike(aid,arow,ai,trow,ti,gh){
STRK=true;G.pz=0;newAttack();const gid=G.id,a=G.s[aid][arow][ai],za=`${aid}-${arow}-${ai}`,tid=OPP(aid),zt=trow==='hq'?tid+'-hq':`${tid}-${trow}-${ti}`,K=a.cat,live=()=>G&&G.id===gid;
const se=Z(za),te=Z(zt),big=trow==='hq'||K==='art';
if(RM()||!se||!te){sfxFire(a,trow);if(K==='art')sfxFlight(a);sfxImpact(a,trow,K==='art'?.42:.14);killG(gh);unlift();attack(aid,arow,ai,trow,ti);vib(big?[50,25,80]:30);return}
const s=SC(),c0=ctr(se),c1=ctr(te);
LIFT=za;se.classList.add('lifted');
if(!gh)gh=mkGhost(za,c0.x,c0.y,1,.5);
if(!gh){unlift();attack(aid,arow,ai,trow,ti);return}
try{
if(K==='art'){const h=atC(gh,c0.x,c0.y,1),dir=aid==='p'?1:-1;await mvG(gh,h.x,h.y+dir*5*s,1.04,70,'ease-in');sfxFire(a,trow);sfxFlight(a);const fl=shellFly(c0,c1,430);mvG(gh,h.x,h.y,1,220);await fl}
else{sfxFire(a,trow);const air=K==='air',r=air?1:.82,p=atC(gh,c0.x+(c1.x-c0.x)*r,c0.y+(c1.y-c0.y)*r,air?1.18:1.1);await mvG(gh,p.x,p.y,p.k,air?230:200,'cubic-bezier(.5,0,.9,.55)')}
if(!live())return;
sfxImpact(a,trow);attack(aid,arow,ai,trow,ti);vib(big?[50,25,80]:30);if(big)shakeB();render();if(G.pz){const pz=G.pz;G.pz=0;await sleep(pz);if(!live())return}
if(G.s[aid][arow][ai]===a){const ne=Z(za);if(ne){const c=ctr(ne),p=atC(gh,c.x,c.y,1);await mvG(gh,p.x,p.y,1,200)}}else await fadeG(gh,140)
}finally{killG(gh);unlift()}}
export const set_LIFT=v=>LIFT=v;
export const set_STRK=v=>STRK=v;
