/* Iron Front — data/config.js
 * Dados declarativos: constantes de regra (CFG), nomes de categorias e palavras-chave, tabelas de reações.
 */
export const CFG={hq:20,hand:8,maxCp:7,drawAt:7,lsAt:7,lsDiff:3,lsFew:4,lsHq:8,slots:5,startP:3,startE:5,fatigue:1,dmg:3,heal:4,airHq:1,aa:1,bar:3,barMax:2,barHit:2,barCost:2};
const EMO={inf:'🪖',art:'💣',arm:'⚙️',air:'✈️',ops:'📜',rx:'⚡'};
export const CATN={inf:'Infantaria',art:'Artilharia',arm:'Blindado',air:'Aviação',ops:'Operação',rx:'Reação'};
export const TAG={guard:'GUARDA',build:'ESCUDO',rush:'ASSALTO',go:'ENTRA ATACANDO',fly:'VOO',dmg3:'DANO 3',draw2:'COMPRA 2',heal4:'CURA 4',armor:'COURAÇA',barrage:'BARRAGEM',infil:'INFILTRAÇÃO',siege:'CERCO',mine:'MINAS',counter:'CONTRABAT.',wire:'ARAME',aa:'ANTIAÉREA',e_draw:'ENTRA +CARTA',e_cp:'ENTRA +CMD',e_hq1:'ENTRA QG-1',c_heal:'CAI: CURA',c_pos:'CAI: TRINCH.',c_wreck:'CAI: EXPLODE',c_rev:'CAI: VINGANÇA'};
export const NAMES={a:'Aliados',c:'Potências Centrais'};
export const MOBAT=5;
export const SCHL=3;
export const CDR=3;
export const RXK={mine:'arm',counter:'art',wire:'inf',aa:'air'};
export const RXD={mine:3,counter:2,wire:2,aa:2};
