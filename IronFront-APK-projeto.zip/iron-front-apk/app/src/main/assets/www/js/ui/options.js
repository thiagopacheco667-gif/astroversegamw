/* Iron Front — ui/options.js
 * Opções do jogador (chave ironfront.opts): carregar, gravar e refletir na interface.
 */
import {$} from '../core/util.js';
import {VOL, ambOn, muted, set_ambOn, set_muted, set_vibOn, vibOn} from './audio.js';

const OPK='ironfront.opts';
export function loadOpts(){try{const o=JSON.parse(localStorage.getItem(OPK));if(o){set_muted(!!o.m);set_vibOn(o.v!==false);set_ambOn(o.a!==false);for(const k of['m','s','a']){const x=o['v'+k];if(typeof x==='number'&&x>=0&&x<=1)VOL[k]=x}}}catch(e){}$('#bm').textContent=muted?'🔇':'🔊';$('#bv').classList.toggle('on',vibOn);uiAud()}
export function uiAud(){const b=$('#bamb');if(b){b.classList.toggle('on',ambOn);b.textContent=ambOn?'🌬 Ambiente: ligado':'🌬 Ambiente: desligado'}for(const k of['m','s','a']){const e=$(k==='s'?'#vols_':'#vol'+k);if(e)e.value=Math.round(VOL[k]*100)}}
export function optSave(){try{localStorage.setItem(OPK,JSON.stringify({m:muted,v:vibOn,a:ambOn,vm:VOL.m,vs:VOL.s,va:VOL.a}))}catch(e){}}
