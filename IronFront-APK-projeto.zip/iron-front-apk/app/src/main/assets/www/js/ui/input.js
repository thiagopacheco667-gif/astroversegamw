/* Iron Front — ui/input.js
 * Entrada do jogador: toque/clique, arrastar, toque longo e botões.
 */
import {G, SAVED, TUT, diff, pf, set_diff, set_pf} from '../core/state.js';
import {$, esc} from '../core/util.js';
import {cmSel} from '../data/commanders.js';
import {CATN, CFG} from '../data/config.js';
import {aiTurn} from '../systems/battle/ai.js';
import {build, buildHint, buildWhy, cmdOk, endTurnFx, goWhy, place, rowOf, setRx, start, targets, useCmd, useOp, why} from '../systems/battle/engine.js';
import {restore} from '../systems/save/match.js';
import {startMis, tutNext, tutOk, tutSkip} from '../systems/tutorial/tutorial.js';
import {LIFT, SC, STRK, Z, backG, fadeG, mkGhost, setG, set_LIFT, set_STRK, settleG, strike, unlift} from './animation.js';
import {ambOn, ambSync, muted, set_ambOn, set_muted, set_vibOn, sfx, stopSfx, vib, vibOn} from './audio.js';
import {toast} from './effects.js';
import {optSave, uiAud} from './options.js';
import {render} from './render.js';
import {acat, adet, cardAt, gloHTML, kwShow, memHTML, openPage, refreshRs, renderArq, renderOp, scr, set_acat, showCm, showFd, stats} from './screens.js';

export function tap(z){if(!G||G.over||G.busy||G.turn!=='p')return;G.cmdArm=0;const[id,row,ix]=z.split('-'),i=+ix,S=G.s.p,sel=G.sel;if(TUT&&!tutOk(z)){toast('Siga o guia no alto da tela.');return}if(id==='e'&&row!=='hq'&&G.s.e[row]&&G.s.e[row][i])sfx('card');
if(row==='hand'){const c=S.hand[i];G.detail=c;
if(sel&&sel.kind==='hand'&&sel.c===c){if(c.ab==='heal4'&&S.hq>=CFG.hq){toast('Seu QG já está com a resistência máxima.');G.sel=null;return render()}if(c.cat==='ops'&&c.ab!=='dmg3')useOp('p',c);else if(c.cat==='rx')setRx('p',c);G.sel=null;return render()}
if(c.cost>S.cp){toast('Custa '+c.cost+' e você tem '+S.cp+' pontos. Encerre o turno para ganhar mais.');G.sel=null;return render()}
G.sel={kind:'hand',c};toast(c.cat==='rx'?'Toque de novo para armar a reação (oculta ao inimigo).':c.cat!=='ops'?'Escolha uma posição marcada com +.':c.ab==='dmg3'?'Escolha um alvo inimigo.':'Toque de novo na carta para usá-la.');return render()}
const card=row==='hq'?null:G.s[id][row][i];if(card)G.detail=card;if(row==='hq')G.detail={hq:id};
if(sel&&sel.kind==='hand'){const c=sel.c;
if(c.cat!=='ops'&&c.cat!=='rx'&&id==='p'){if(row!==rowOf(c))toast(CATN[c.cat]+' só pode ocupar a '+(rowOf(c)==='front'?'linha de frente.':'retaguarda.'));else if(card)toast('Posição ocupada.');else{place('p',c,i);G.sel=null}return render()}
if(c.ab==='dmg3'&&id==='e'){if(row!=='hq'&&!card){toast('Escolha uma unidade ou o QG inimigo.');return render()}useOp('p',c,{row,i});G.sel=null;return render()}}
if(sel&&sel.kind==='unit'&&sel.c.ab==='build'&&id==='p'&&card&&card!==sel.c){const w=buildWhy(S,row,i,sel.c);if(w){toast(w);return render()}build('p',sel.c,row,i);G.sel=null;return render()}
if(sel&&sel.kind==='unit'&&id==='e'){if(row!=='hq'&&!card){toast('Sem alvo nessa posição.');return render()}const w=why(sel.c,'e',row,i);if(w){toast(w);return render()}const s0=sel,g0=G;G.sel=null;G.busy=true;render();strike('p',s0.row,s0.i,row,i,DRAGGH&&DRAGGH.z===`p-${s0.row}-${s0.i}`?DRAGGH:null).catch(()=>{}).finally(()=>{if(G===g0){G.busy=false;render()}});return}
if(id==='p'&&card){if(sel&&sel.c===card){G.sel=null;return render()}
if(card.att)toast('Esta unidade já agiu neste turno.');else if(!card.ready)toast('Recém-mobilizada: só age no próximo turno.');else{G.sel={kind:'unit',row,i,c:card};{const T=targets('p',card);toast(card.ab==='build'?buildHint(S,card):!T.length?'Nenhum alvo válido para esta unidade agora.':T.some(t=>t.row==='hq')?'QG inimigo exposto! Toque no QG (à esquerda) para atacar.':'Escolha um alvo marcado com ✛. O selo ↩ mostra o revide; ☠ avisa que sua unidade cai.')}}return render()}
G.sel=null;render()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');
if(b){const a=b.dataset.act,v=b.dataset.v;sfx('ui');
if(a==='f'||a==='d'){(a==='f'?$('#fs'):$('#ds')).querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));a==='f'?set_pf(v):set_diff(v);if(a==='f')showFd();else renderOp()}
else if(a==='go'){start();const d=document.documentElement;try{(d.requestFullscreen?d.requestFullscreen():Promise.reject()).then(()=>screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape')).catch(()=>{})}catch(_){}}
else if(a==='fs'){const d=document.documentElement;try{(d.requestFullscreen?d.requestFullscreen():Promise.reject()).then(()=>screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape')).catch(()=>{})}catch(_){}}
else if(a==='resume'){if(G&&!G.over)$('#ov').hidden=true;else if(SAVED){restore(SAVED);$('#ov').hidden=true}}
else if(a==='rot')$('#rot').classList.add('ok');
else if(a==='mis')startMis(v);else if(a==='gl')openPage('Glossário',gloHTML());else if(a==='mem')openPage('Memorial',memHTML());else if(a==='pgx')$('#pg').hidden=true;
else if(a==='vib'){set_vibOn(!vibOn);b.classList.toggle('on',vibOn);optSave();if(vibOn)vib(30)}
else if(a==='tn')tutNext();else if(a==='ts')tutSkip();
else if(a==='cm'){cmSel[pf]=v;showCm()}
else if(a==='cmd'){if(!G||G.over||G.busy||G.turn!=='p'||(TUT&&!(TUT.m&&TUT.m.cmd)))return;const w=cmdOk('p');G.detail={cmd:1};if(w){toast(w);G.cmdArm=0}else if(!G.cmdArm){G.cmdArm=1;toast('Toque de novo para ordenar.')}else{G.cmdArm=0;useCmd('p')}render()}
else if(a==='logp'){if(G)openPage('Registro da batalha',G.log.length?G.log.map(l=>'<div class="kwi">• '+esc(l)+'</div>').join(''):'<div class="kwi">Nada registrado ainda.</div>')}
else if(a==='scr')scr(v)
else if(a==='ac'){set_acat(v);renderArq()}
else if(a==='ak'){$('#ad').innerHTML=adet(v);document.querySelectorAll('#ab .ac').forEach(x=>x.classList.toggle('sel',x===b))}
else if(a==='mute'){set_muted(!muted);b.textContent=muted?'🔇':'🔊';optSave();if(muted)stopSfx(.05);ambSync()}
else if(a==='amb'){set_ambOn(!ambOn);uiAud();optSave();ambSync()}
else if(a==='rm'){document.body.classList.toggle('rm');b.classList.toggle('on')}
else if(a==='menu'){$('#msg').textContent='Iniciar uma nova batalha substitui a partida atual.';refreshRs();scr('home');$('#ov').hidden=false;stats()}
else if(a==='end'&&G&&!G.over&&!G.busy&&G.turn==='p'){if(TUT&&!TUT.m.end)toast(TUT.m?'Esta missão se resolve neste turno.':'Siga o guia no alto da tela.');else{G.sel=null;endTurnFx('p');G.turn='e';aiTurn()}}
return}
const z=e.target.closest('[data-z]');if(z)tap(z.dataset.z)});
let DR=null;
let SUP=false;
let GH=null;
let DRAGGH=null;
let LPT=0;
let LPX=0;
let LPY=0;
export const app=$('#app');
document.addEventListener('click',e=>{if(SUP){SUP=false;e.stopPropagation();e.preventDefault()}},true);
app.addEventListener('contextmenu',e=>e.preventDefault());
const lpEnd=()=>{clearTimeout(LPT);LPT=0;if(SUP)setTimeout(()=>SUP=false,70)};
document.addEventListener('pointerdown',e=>{const k=$('#kw');if(!k.hidden)k.hidden=true;clearTimeout(LPT);LPT=0;
const el=e.target.closest&&e.target.closest('[data-z]');if(!el||!G||!el.querySelector('.c'))return;
LPX=e.clientX;LPY=e.clientY;const z=el.dataset.z;
LPT=setTimeout(()=>{LPT=0;const c=cardAt(z),w=goWhy(c);if(c&&(c.ab||c.ent||c.cai||w>1)){kwShow([c.ab,c.ent,c.cai].filter(Boolean).concat(w>1?['go']:[]));SUP=true;DR=null}},430)},true);
document.addEventListener('pointerup',lpEnd,true);
app.addEventListener('pointerdown',e=>{if(!G||G.over||G.busy||G.turn!=='p')return;const el=e.target.closest('[data-z]');if(!el||!/^p-(hand|front|rear)-/.test(el.dataset.z))return;
DR={z:el.dataset.z,x:e.clientX,y:e.clientY,id:e.pointerId,on:false,moved:false};if(el.querySelector('.c'))sfx('card')});
app.addEventListener('pointermove',e=>{if(LPT&&Math.hypot(e.clientX-LPX,e.clientY-LPY)>10){clearTimeout(LPT);LPT=0}
if(!DR||e.pointerId!==DR.id)return;
if(!DR.on){if(Math.hypot(e.clientX-DR.x,e.clientY-DR.y)<10)return;DR.moved=true;G.sel=null;tap(DR.z);if(!G.sel){SUP=true;setTimeout(()=>SUP=false,400);DR=null;return}
DR.on=true;try{app.setPointerCapture(e.pointerId)}catch(_){}
set_LIFT(DR.z);const src=Z(DR.z);if(src)src.classList.add('lifted');
GH=mkGhost(DR.z,e.clientX,e.clientY,1.08,/-hand-/.test(DR.z)?.72:.95);sfx('lift')}
if(GH){const s=SC();setG(GH,e.clientX-GH.w*s*1.08/2,e.clientY-GH.h*s*1.08*GH.oy,1.08)}});
app.addEventListener('pointerup',e=>{if(!DR||e.pointerId!==DR.id)return;const d=DR;DR=null;if(d.moved){SUP=true;setTimeout(()=>SUP=false,40)}
if(!d.on)return;
const sel=G.sel,gh=GH;GH=null;const t=document.elementFromPoint(e.clientX,e.clientY),zt=t&&t.closest('[data-z]'),z2=zt&&zt.dataset.z;
if(!z2||!sel||/^p-hand/.test(z2)||z2===d.z){G.sel=null;render();backG(gh,d.z);return}
if(sel.kind==='hand'&&sel.c.cat==='rx'){if(setRx('p',sel.c)){G.sel=null;unlift();render();fadeG(gh,120)}else{G.sel=null;render();backG(gh,d.z)}return}
if(sel.kind==='hand'&&sel.c.cat==='ops'&&sel.c.ab!=='dmg3'){
if(sel.c.ab==='heal4'&&G.s.p.hq>=CFG.hq){toast('Seu QG já está com a resistência máxima.');G.sel=null;render();backG(gh,d.z)}
else{useOp('p',sel.c);G.sel=null;unlift();render();fadeG(gh,120)}return}
set_STRK(false);DRAGGH=gh;tap(z2);DRAGGH=null;
if(!STRK){if(sel.kind==='hand'&&!G.s.p.hand.includes(sel.c))settleG(gh,z2);else backG(gh,d.z)}});
app.addEventListener('pointercancel',()=>{clearTimeout(LPT);LPT=0;const z=DR&&DR.z,g=GH;GH=null;DR=null;if(g){if(G)G.sel=null;backG(g,z);if(G)render()}});
