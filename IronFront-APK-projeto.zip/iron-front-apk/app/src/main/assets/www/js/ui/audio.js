/* Iron Front — ui/audio.js
 * Áudio: mixer, sons sintetizados, amostras gravadas (assets/audio/) e vibração.
 */
export let muted=false;
export let ac=null;
let mg=null;
let sb=null;
let ab=null;
let NB=null;
export let ambOn=true;
export let VOL={m:.9,s:1,a:.6};
let AMBK=.5;
export let vibOn=true;
export function applyVol(){if(!ac)return;mg.gain.value=VOL.m;sb.gain.value=VOL.s;ab.gain.cancelScheduledValues(0);ab.gain.value=VOL.a*AMBK}
function mk(){if(ac)return ac;ac=new(window.AudioContext||window.webkitAudioContext)();const c=ac.createDynamicsCompressor();c.threshold.value=-3;c.knee.value=2;c.ratio.value=20;c.attack.value=.002;c.release.value=.12;mg=ac.createGain();mg.connect(c);c.connect(ac.destination);sb=ac.createGain();sb.connect(mg);ab=ac.createGain();ab.connect(mg);applyVol();NB=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;return ac}
export function A(){mk();if(ac.state==='suspended')ac.resume();return ac}
function nz(t,d,o={}){const s=ac.createBufferSource();s.buffer=NB;s.loop=true;const f=ac.createBiquadFilter();f.type=o.ty||'lowpass';f.Q.value=o.q||.7;f.frequency.setValueAtTime(o.a||1000,t);if(o.b)f.frequency.exponentialRampToValueAtTime(o.b,t+d);const g=ac.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(o.g||.4,t+(o.at||.003));g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(sb);s.start(t,Math.random()*1.4);s.stop(t+d+.05)}
function tn(t,d,o={}){const s=ac.createOscillator(),g=ac.createGain();s.type=o.ty||'sine';s.frequency.setValueAtTime(o.a||100,t);if(o.b)s.frequency.exponentialRampToValueAtTime(o.b,t+d);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(o.g||.3,t+(o.at||.004));g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(g);g.connect(sb);s.start(t);s.stop(t+d+.05)}
const crack=(t,v=1)=>{nz(t,.1,{ty:'highpass',a:2200,b:700,g:.55*v,at:.0006});nz(t,.07,{ty:'bandpass',a:2800,q:1.1,g:.45*v,at:.0006});tn(t,.17,{a:160,b:55,g:.42*v,at:.001});nz(t+.035,.45,{ty:'lowpass',a:1000,b:140,g:.2*v,at:.015})};
const SND={
ui:t=>tn(t,.03,{ty:'triangle',a:620,b:480,g:.05}),
card:t=>{nz(t,.055,{ty:'bandpass',a:3400,b:1500,q:.9,g:.4,at:.001});nz(t+.012,.04,{ty:'highpass',a:5000,g:.14,at:.001});tn(t,.05,{a:240,b:130,g:.16})},
lift:t=>{nz(t,.16,{ty:'bandpass',a:800,b:3400,q:.8,g:.32,at:.03});tn(t,.1,{a:200,b:300,g:.05})},
draw:t=>{nz(t,.06,{ty:'bandpass',a:3000,b:1200,q:.9,g:.3,at:.001});nz(t+.04,.05,{ty:'highpass',a:4500,g:.12,at:.001})},
place:t=>{nz(t,.1,{ty:'lowpass',a:3200,b:450,g:.6,at:.001});nz(t,.035,{ty:'highpass',a:3500,g:.22,at:.001});tn(t,.13,{a:180,b:70,g:.5,at:.002})},
op:t=>{nz(t,.2,{ty:'bandpass',a:600,b:2600,q:.7,g:.35,at:.04});nz(t+.19,.07,{ty:'lowpass',a:2600,b:500,g:.45,at:.001});tn(t+.19,.12,{a:150,b:60,g:.35})},
star:t=>{tn(t,.3,{ty:'triangle',a:880,b:1320,g:.13});tn(t+.09,.3,{ty:'triangle',a:1320,b:1760,g:.09})},
volley:t=>{crack(t,1);crack(t+.1,.8);crack(t+.19,.9)},
mgun:t=>{for(let i=0;i<7;i++)crack(t+i*.062+Math.random()*.012,.5+Math.random()*.2)},
cannon:t=>{tn(t,.55,{a:120,b:34,g:.85,at:.002});nz(t,.65,{ty:'lowpass',a:1000,b:80,g:.75,at:.002});nz(t+.05,1,{ty:'lowpass',a:320,b:45,g:.4,at:.08})},
whistle:t=>tn(t,.42,{a:2400,b:650,g:.07}),
boomS:t=>{tn(t,.35,{a:100,b:34,g:.6});nz(t,.45,{ty:'lowpass',a:1400,b:120,g:.5,at:.002})},
boomM:t=>{tn(t,.8,{a:90,b:26,g:.9});nz(t,.9,{ty:'lowpass',a:1600,b:70,g:.8,at:.002});nz(t+.07,1,{ty:'lowpass',a:280,b:40,g:.5,at:.07});for(let k=0;k<5;k++)nz(t+.14+k*.07+Math.random()*.05,.12,{ty:'highpass',a:2000+Math.random()*2500,g:.1,at:.002})},
boomL:t=>{SND.boomM(t);tn(t+.02,1.1,{a:60,b:20,g:.9})},
hit:t=>{tn(t,.14,{a:150,b:55,g:.5,at:.002});nz(t,.1,{ty:'lowpass',a:1800,b:300,g:.4,at:.001})},
hqhit:t=>{tn(t,.45,{a:80,b:28,g:.8});nz(t,.5,{ty:'lowpass',a:1100,b:90,g:.6,at:.002});nz(t+.05,.2,{ty:'highpass',a:1500,g:.15})},
engine:t=>{const d=.85,o1=ac.createOscillator(),o2=ac.createOscillator(),f=ac.createBiquadFilter(),g=ac.createGain(),lf=ac.createOscillator(),lg=ac.createGain();o1.type='sawtooth';o2.type='sawtooth';o1.frequency.setValueAtTime(68,t);o1.frequency.linearRampToValueAtTime(100,t+d);o2.frequency.setValueAtTime(72,t);o2.frequency.linearRampToValueAtTime(106,t+d);f.type='lowpass';f.frequency.value=650;lf.frequency.value=28;lg.gain.value=.07;lf.connect(lg);lg.connect(g.gain);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.2,t+d*.4);g.gain.linearRampToValueAtTime(.0001,t+d);o1.connect(f);o2.connect(f);f.connect(g);g.connect(sb);[o1,o2,lf].forEach(o=>{o.start(t);o.stop(t+d+.05)});nz(t,d,{ty:'bandpass',a:450,b:900,q:.7,g:.1,at:d*.4})},
tank:t=>{nz(t,.75,{ty:'lowpass',a:170,b:80,g:.6,at:.06});tn(t,.7,{ty:'sawtooth',a:46,b:38,g:.18,at:.1});tn(t+.1,.09,{ty:'square',a:340,b:210,g:.1});tn(t+.24,.09,{ty:'square',a:300,b:180,g:.09})},
win:t=>{[392,523,659,784].forEach((f,i)=>tn(t+i*.16,i===3?.7:.28,{ty:'triangle',a:f,g:.2}))},
lose:t=>{tn(t,1.3,{ty:'sawtooth',a:120,b:60,g:.12});SND.boomM(t+.1)}
};
SND.click=SND.ui;
SND.play=SND.place;
SND.boom=SND.boomM;
SND.rifle=t=>crack(t,1);
SND.bolt=t=>SND.card(t);
SND.mgV=SND.mgM=SND.mgA=SND.mgun;
SND.fieldgun=SND.heavygun=SND.cannon;
export const AUD={
rifle:{f:['infantaria/rifle_tiro_1','infantaria/rifle_tiro_2','infantaria/rifle_tiro_3','infantaria/rifle_tiro_4','infantaria/rifle_tiro_5'],g:.62,p:2},
bolt:{f:['infantaria/ferrolho_recarga_1','infantaria/ferrolho_recarga_2','infantaria/ferrolho_recarga_3','infantaria/ferrolho_recarga_4'],g:.34,p:1,rv:.03},
mgV:{f:['metralhadoras/vickers_rajada_1','metralhadoras/vickers_rajada_2'],g:.6,p:2},
mgM:{f:['metralhadoras/maxim_mg08_rajada_1','metralhadoras/maxim_mg08_rajada_2'],g:.6,p:2},
mgA:{f:['metralhadoras/metralhadora_aviao_rajada'],g:.5,p:2},
fieldgun:{f:['artilharia/canhao_campanha_tiro'],g:.7,p:3,tail:1.1},
heavygun:{f:['artilharia/obus_pesado_tiro'],g:.7,p:4,tail:1.6},
boomS:{f:['explosoes/explosao_pequena'],g:.5,p:3},
boomM:{f:['explosoes/explosao_media'],g:.66,p:3,big:1,tail:2.6},
boomL:{f:['explosoes/explosao_pesada'],g:.72,p:4,big:1,tail:2.8},
amb:{f:['ambiente/vento_loop']}};
export const BUF={};
const LK={};
const LT={};
const VO=[];
const MAXV=20;
const HEAVY=new Set(['a7','c7']);
const FIGHT=new Set(['a10','c10']);
let AMB=null;
let LASTBIG=-9;
const has=n=>!!(BUF[n]&&BUF[n].length);
const dec=b=>new Promise((ok,no)=>{const p=ac.decodeAudioData(b,ok,no);if(p&&p.catch)p.catch(no)});
export async function loadAud(){try{mk()}catch(e){return}
await Promise.all(Object.entries(AUD).map(async([k,d])=>{const L=[];for(const f of d.f){try{const r=await fetch('assets/audio/'+f+'.wav');if(!r.ok)continue;L.push(await dec(await r.arrayBuffer()))}catch(e){}}if(L.length){BUF[k]=L;if(k==='amb')ambSync()}}))}
function duck(t){if(!ab)return;const n=Math.max(t,ac.currentTime),b=VOL.a*AMBK;ab.gain.cancelScheduledValues(n);ab.gain.setTargetAtTime(b*.4,n,.03);ab.gain.setTargetAtTime(b,n+.9,.6)}
function fadeV(o,tc,end,at=0){const n=ac.currentTime+at;try{o.g.gain.cancelScheduledValues(n);o.g.gain.setValueAtTime(at>0||!o.fd?o.v:o.g.gain.value,n);o.g.gain.setTargetAtTime(0,n,tc);o.s.stop(n+end)}catch(e){}o.e=Math.min(o.e,n+end)}
function duckGun(dl){if(!ac)return;for(const o of VO)if((o.n==='fieldgun'||o.n==='heavygun')&&!o.fd){o.fd=1;fadeV(o,.07,.4,dl)}}
export function newAttack(){if(!ac)return;const n=ac.currentTime;for(const o of VO)if(o.t<=n+.02&&o.e-n>.35&&!o.fd){o.fd=1;fadeV(o,o.p>=3?.16:.1,o.p>=3?.8:.5)}}
function smp(n,dl=0,v=1){const d=AUD[n];if(!ac||!has(n))return false;const t=ac.currentTime+dl,now=ac.currentTime;
if(Math.abs(t-(LT[n]===undefined?-9:LT[n]))<.02)return true;LT[n]=t;
for(let i=VO.length-1;i>=0;i--)if(VO[i].e<now)VO.splice(i,1);
if(VO.length>=MAXV){if(d.p<=1)return true;let k=-1;for(let i=0;i<VO.length;i++){const o=VO[i];if(o.t>now)continue;if(k<0||o.p<VO[k].p||(o.p===VO[k].p&&o.t<VO[k].t))k=i}if(k>=0){const o=VO.splice(k,1)[0];fadeV(o,.04,.2)}}
const L=BUF[n];let k=Math.random()*L.length|0;if(L.length>1&&k===LK[n])k=(k+1)%L.length;LK[n]=k;
const s=ac.createBufferSource(),g=ac.createGain(),rv=d.rv||.05,gv=d.g*v*(.92+Math.random()*.16),dur=L[k].duration/(1+0*rv);s.buffer=L[k];s.playbackRate.value=1+(Math.random()*2-1)*rv;g.gain.value=gv;s.connect(g);g.connect(sb);
let end=t+L[k].duration/s.playbackRate.value+.05;
if(d.tail&&d.tail<dur-.4){g.gain.setValueAtTime(gv,t+d.tail);g.gain.linearRampToValueAtTime(.0001,t+d.tail+.5);end=t+d.tail+.6}
const o={s,g,p:d.p,t,e:end,n,v:gv};VO.push(o);s.onended=()=>{const i=VO.indexOf(o);if(i>=0)VO.splice(i,1);try{g.disconnect()}catch(e){}};s.start(t);s.stop(end);
if(d.big)duck(t);return true}
export function stopSfx(f=.12){if(!ac)return;const n=ac.currentTime;for(const o of VO.splice(0)){try{o.g.gain.cancelScheduledValues(n);o.g.gain.setTargetAtTime(0,n,f/4);o.s.stop(n+f+.05)}catch(e){}}}
export function ambSync(){if(!ac||!ab)return;const on=ambOn&&!muted&&has('amb'),n=ac.currentTime;
if(on&&!AMB){const s=ac.createBufferSource(),g=ac.createGain();s.buffer=BUF.amb[0];s.loop=true;g.gain.setValueAtTime(.0001,n);g.gain.linearRampToValueAtTime(1,n+2.5);s.connect(g);g.connect(ab);s.start();AMB={s,g}}
else if(!on&&AMB){const o=AMB;AMB=null;o.g.gain.cancelScheduledValues(n);o.g.gain.setValueAtTime(o.g.gain.value,n);o.g.gain.linearRampToValueAtTime(0,n+.5);try{o.s.stop(n+.6)}catch(e){}}}
export function sfx(n,dl=0){if(muted)return;try{A();if(n==='boomM'||n==='boomL')LASTBIG=ac.currentTime+dl;
if(n==='volley'&&has('rifle')){const c=2+(Math.random()*2|0);for(let i=0;i<c;i++)smp('rifle',dl+i*(.07+Math.random()*.04),1-i*.07);return}
if(smp(n,dl))return;const f=SND[n];if(f)f(ac.currentTime+dl)}catch(e){}}
export function dieSfx(){if(ac&&ac.currentTime-LASTBIG<.7)return;sfx('boomS',.1)}
export function sfxFire(a,trow){const K=a.cat;
if(K==='art')sfx(HEAVY.has(a.id)?'heavygun':'fieldgun');
else if(K==='air'){sfx('engine');if(FIGHT.has(a.id))sfx('mgA',.12)}
else if(K==='arm'){sfx('tank');sfx('cannon',.1)}
else if(a.ab==='guard')sfx(a.id==='c3'?'mgM':'mgV');
else sfx('volley')}
export function sfxFlight(a){if(a.cat==='art')sfx('whistle',.03)}
export function sfxImpact(a,trow,dl=0){const h=trow==='hq',K=a.cat;
if(K==='art'){duckGun(dl);sfx(h||HEAVY.has(a.id)?'boomL':'boomM',dl)}else sfx(h?'hqhit':'hit',dl);
if(K==='inf'&&a.ab!=='guard')sfx('bolt',dl+.5)}
export function vib(p){if(vibOn&&navigator.vibrate)try{navigator.vibrate(p)}catch(e){}}
export const set_muted=v=>muted=v;
export const set_vibOn=v=>vibOn=v;
export const set_ambOn=v=>ambOn=v;
