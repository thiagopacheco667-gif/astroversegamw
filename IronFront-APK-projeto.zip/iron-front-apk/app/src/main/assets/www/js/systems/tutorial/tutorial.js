/* Iron Front — systems/tutorial/tutorial.js
 * Tutorial guiado: balão, verificação de passos, entrada e saída das missões.
 */
import {G, TUT, diff, pf, set_G, set_TUT, set_diff, set_pf} from '../../core/state.js';
import {$} from '../../core/util.js';
import {ACA, acaGo, acaMark} from '../academy/academy.js';
import {SAVE, save} from '../save/profile.js';
import {NAMEUSE} from '../soldiers.js';
import {MIS_DEF} from './missions.js';
import {render} from '../../ui/render.js';
import {scr} from '../../ui/screens.js';

export function tutOk(z){return true}
export function hideCoach(){const c=$('#coach');if(c)c.hidden=true;document.body.classList.remove('tut');document.querySelectorAll('.hl').forEach(e=>e.classList.remove('hl'))}
function tutUI(){document.querySelectorAll('.hl').forEach(e=>e.classList.remove('hl'));const c=$('#coach');
if(!TUT||!G){c.hidden=true;document.body.classList.remove('tut');return}
document.body.classList.add('tut');if(G.busy&&G.turn==='e'){c.hidden=true;return}
if(TUT.m){const m=TUT.m;c.classList.add('ms');c.hidden=false;$('#ct').innerHTML=m.t+'<span class="stp">'+(TUT.back?'Exercício':'Missão')+'</span>';$('#cx').textContent=TUT.st?TUT.tx:m.x;const nb=$('#cn');nb.hidden=false;nb.textContent=TUT.st==='ok'?'Concluir':'Reiniciar';return}
}
export function tutCheck(){if(!TUT||!G)return;if(TUT.m){if(!TUT.st){const r=TUT.m.check();if(r){TUT.st=r[0];TUT.tx=r[1];if(r[0]==='ok'){if(TUT.back)acaMark('p',TUT.k);else if(!SAVE.ms.includes(TUT.k)){SAVE.ms.push(TUT.k);save()}}}}tutUI();return}}
export function tutNext(){if(!TUT||!TUT.m)return;if(TUT.st==='ok')misExit();else if(TUT.back)acaGo(TUT.m,TUT.k);else startMis(TUT.k)}
export function tutSkip(){if(TUT&&TUT.m)misExit()}
export function renderTrn(){$('#tb').innerHTML=Object.entries(MIS_DEF).map(([k,m])=>`<button class="mi" data-act="mis" data-v="${k}"><i>${m.ic}</i><span><b>${m.t}${SAVE.ms.includes(k)?' ✓':''}</b><small>${m.s}</small></span></button>`).join('')+`<div class="kwi">Missões de um turno com o tabuleiro já montado. Reinicie quantas vezes quiser. Concluídas: <b>${SAVE.ms.length}/${Object.keys(MIS_DEF).length}</b></div>`}
export function startMis(k){const m=MIS_DEF[k];if(!m)return;set_pf('a');set_diff('normal');NAMEUSE.clear();set_TUT({i:0,m,k,st:0,d:{}});m.setup();$('#ov').hidden=true;render()}
function misExit(){const b=TUT&&TUT.back;if(b)ACA.keep=1;set_TUT(null);hideCoach();set_G(null);scr(b||'trn');$('#ov').hidden=false}
