/* Iron Front — systems/save/profile.js
 * Perfil permanente (chave localStorage ironfront.v1): leitura tolerante e gravação. Comportamento idêntico ao original; sem migração (Fase 2).
 */
export let SAVE={w:0,l:0,t:0,f:0,m:[],ms:[]};
try{const s=JSON.parse(localStorage.getItem('ironfront.v1'));if(s&&Number.isInteger(s.w)&&Number.isInteger(s.l)){SAVE.w=s.w;SAVE.l=s.l;SAVE.t=s.t?1:0;SAVE.ms=Array.isArray(s.ms)?s.ms.filter(x=>typeof x==='string').slice(0,20):[];SAVE.f=Number.isInteger(s.f)&&s.f>=0?s.f:0;SAVE.m=Array.isArray(s.m)?s.m.filter(x=>x&&typeof x.n==='string').slice(0,30).map(x=>({n:String(x.n).slice(0,60),d:String(x.d||'').slice(0,120),s:Math.max(0,Math.min(3,+x.s||0))})):[]}}catch(e){}
try{const s2=JSON.parse(localStorage.getItem('ironfront.v1')),a=s2&&s2.ac;if(a&&typeof a==='object'){SAVE.ac={f:(Array.isArray(a.f)?a.f:[]).filter(x=>Number.isInteger(x)&&x>=0&&x<20).slice(0,20),a:(Array.isArray(a.a)?a.a:[]).filter(x=>typeof x==='string'&&x.length<8).slice(0,10),c:(Array.isArray(a.c)?a.c:[]).filter(x=>typeof x==='string'&&x.length<8).slice(0,60),p:(Array.isArray(a.p)?a.p:[]).filter(x=>typeof x==='string'&&x.length<14).slice(0,200)}}}catch(e){}
export const save=()=>{try{localStorage.setItem('ironfront.v1',JSON.stringify(SAVE))}catch(e){}};
