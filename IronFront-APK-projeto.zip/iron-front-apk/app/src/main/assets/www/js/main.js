/* Iron Front — main.js
 * Ponto de entrada: inicialização na mesma ordem do original.
 */
/* A Academia precisa ser o primeiro módulo do grupo interligado a ser avaliado: ela usa MIS_DEF e SAVE já prontos ao carregar. Não reordene. */
import './systems/academy/academy.js';
import './ui/input.js'; /* registra os eventos de toque/clique (nenhum outro módulo importa input.js) */
import './systems/battle/ai.js';
import './ui/layout.js'; /* escala do palco 800x360: precisa executar na carga */
import {SAVED, set_SAVED} from './core/state.js';
import {$} from './core/util.js';
import {HQI, IMG, PIC} from './data/images.js';
import {persist, readSaved} from './systems/save/match.js';
import {A, VOL, ac, ambSync, applyVol, loadAud} from './ui/audio.js';
import {loadOpts, optSave} from './ui/options.js';
import {refreshRs, showFd, stats} from './ui/screens.js';

if('serviceWorker' in navigator&&/^https?:/.test(location.protocol)&&!/IronFrontApp/.test(navigator.userAgent))navigator.serviceWorker.register('sw.js').catch(()=>{});
loadOpts();
loadAud();
document.addEventListener('input',e=>{const t=e.target,k=t&&t.dataset&&t.dataset.vol;if(k){VOL[k]=t.value/100;applyVol();optSave()}});
addEventListener('pointerdown',()=>{try{A();ambSync()}catch(e){}},{once:true,capture:true});
stats();
showFd();
set_SAVED(readSaved());
refreshRs();
if(SAVED){$('#msg').textContent='Há uma partida salva. Continue de onde parou ou inicie uma nova batalha.'}
addEventListener('pagehide',persist);
document.addEventListener('visibilitychange',()=>{if(document.hidden){persist();try{if(ac&&ac.state==='running')ac.suspend()}catch(e){}}else{try{if(ac&&ac.state==='suspended')ac.resume().catch(()=>{})}catch(e){}}});
/* Novo na modularização: as artes agora são arquivos; o pré-carregamento evita piscar ao redesenhar o tabuleiro. */
for(const m of[IMG,HQI,PIC])for(const u of Object.values(m)){const i=new Image();i.src=u}
