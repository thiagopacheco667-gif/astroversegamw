/* Iron Front — systems/soldiers.js
 * Soldados fictícios: gerador, ficha, veterania e memorial dos caídos.
 */
import {TUT} from '../core/state.js';
import {rnd} from '../core/util.js';
import {AGE, PER, ROLE, YR} from '../data/soldiers.js';
import {log} from './battle/engine.js';
import {SAVE, save} from './save/profile.js';
import {sfx} from '../ui/audio.js';
import {fx, toast} from '../ui/effects.js';
import {say} from '../ui/speech.js';

export const NAMEUSE=new Set();
export function mkSoldier(d){const P=PER[d.nat],ag=AGE[d.cat];if(!P||!ag||!ROLE[d.id])return null;let nome,r,pk,age;
for(let t=0;t<8;t++){r=rnd((d.uid||1)*7919+(+d.id.slice(1))*131+d.id.charCodeAt(0)+t*104729);pk=a=>a[r()*a.length|0];age=ag[0]+(r()*(ag[1]-ag[0]+1)|0);nome=P.pat?pk(P.f)+', filho de '+pk(P.f):pk(P.f)+' '+pk(P.l);if(!NAMEUSE.has(nome))break}
NAMEUSE.add(nome);return{n:nome,r:ROLE[d.id],a:age,c:pk(P.c),j:pk(P.j),y:YR[d.id]}}
export function stars(c){const b=c.bt||0;return b>=6?3:b>=4?2:b>=2?1:0}
export function soldierInfo(d){const s=d.sd;if(!s)return'';const st=stars(d);return`<div class="dos"><small>Ficha do combatente · fictício</small><b>${s.n}</b>${st?' <span style="color:#ffd24a">'+'★'.repeat(st)+'</span>':''}<br>${s.r}, ${s.a} anos<br>De ${s.c} · ${s.j}<br>Alistado em ${s.y}${d.bt?'<br>'+(st?'Veterano':'Recruta')+' · '+d.bt+' combate'+(d.bt>1?'s':''):''}</div>`}
export function vet(u,z){if(!u||u.hp<=0||!u.sd)return;const b=stars(u);u.bt=(u.bt||0)+1;const n=stars(u);if(n>b){log('★ '+u.sd.n+' agora é veterano '+'★'.repeat(n));fx(z,'fl','★'.repeat(n));sfx('star',.3)}}
export function fallen(id,u){say(id,'l');const d=u.sd,st=stars(u);if(!d){log(u.nm+' destruída');return}
log('✝ '+d.n+' caiu'+(st?' '+'★'.repeat(st):''));
if(id==='p'&&!TUT){SAVE.f=(SAVE.f||0)+1;SAVE.m.unshift({n:d.n,d:u.nm+' · '+d.r+', '+d.a+' anos, de '+d.c,s:st});SAVE.m.length=Math.min(SAVE.m.length,30);save();toast('✝ '+d.n+' caiu')}}
