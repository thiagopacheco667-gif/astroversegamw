/* Iron Front — ui/speech.js
 * Falas dos comandantes durante a partida.
 */
import {G, TUT} from '../core/state.js';
import {$} from '../core/util.js';
import {CMDS, LN} from '../data/commanders.js';

let SYT={p:0,e:0};
let SYH={};
export function say(sd,kd,force){if(!G||TUT)return;const S=G.s[sd],ln=S&&LN[S.cmd];if(!ln||!ln[kd])return;const now=Date.now();if(!force&&now-SYT[sd]<4500)return;SYT[sd]=now;const L=ln[kd].split('|'),el=$('#say-'+sd),h=document.querySelector('[data-z="'+sd+'-hq"]');if(!el||!h)return;const r=h.getBoundingClientRect();el.innerHTML='<b>'+CMDS[S.cmd].n+'</b>'+L[Math.random()*L.length|0];el.style.left=Math.max(4,r.left)+'px';el.hidden=false;if(sd==='p'){el.style.top='auto';el.style.bottom=(innerHeight-r.top+6)+'px'}else{el.style.bottom='auto';el.style.top=(r.bottom+6)+'px'}clearTimeout(SYH[sd]);SYH[sd]=setTimeout(()=>{el.hidden=true},3400)}
