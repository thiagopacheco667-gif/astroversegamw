/* Iron Front — ui/effects.js
 * Avisos na tela: toast, banner e fila de efeitos visuais (FX).
 */
import {$} from '../core/util.js';

export let FX=[];
let tt=0;
let BNL=[];
let BNT=0;
export function banner(h,side){BNL.push(h);if(BNL.length>3)BNL.shift();const b=$('#bn');b.innerHTML=BNL.map(x=>'<div>'+x+'</div>').join('');b.className=side||'';b.hidden=false;clearTimeout(BNT);BNT=setTimeout(()=>{b.hidden=true;BNL=[]},2600)}
export const fx=(z,t,x)=>FX.push({z,t,x});
export function toast(m){const t=$('#toast');t.textContent=m;clearTimeout(tt);tt=setTimeout(()=>t.textContent='',2200)}
export const set_FX=v=>FX=v;
