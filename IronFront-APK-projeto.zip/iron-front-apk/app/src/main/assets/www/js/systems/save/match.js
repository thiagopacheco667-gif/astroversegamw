/* Iron Front — systems/save/match.js
 * Partida salva (chave ironfront.match.v1): validação, persistência e restauração.
 */
import {G, SAVED, TUT, diff, gidc, next_gidc, pf, set_G, set_SAVED, set_TUT, set_diff, set_pf, set_uid, uid} from '../../core/state.js';
import {$} from '../../core/util.js';
import {CARDS} from '../../data/cards.js';
import {CMDS} from '../../data/commanders.js';
import {CFG, NAMES} from '../../data/config.js';
import {NAMEUSE, mkSoldier} from '../soldiers.js';
import {hideCoach} from '../tutorial/tutorial.js';
import {render} from '../../ui/render.js';
import {showFd} from '../../ui/screens.js';

const MK='ironfront.match.v1';
const okCard=c=>c===null||(c&&typeof c==='object'&&!!CARDS[c.id]&&Number.isFinite(c.hp)&&Number.isFinite(c.uid));
const okSide=S=>!!S&&typeof S==='object'&&Number.isFinite(S.hq)&&Number.isFinite(S.cp)&&Number.isFinite(S.max)&&Number.isFinite(S.tn)&&(S.f==='a'||S.f==='c')&&Array.isArray(S.deck)&&Array.isArray(S.hand)&&Array.isArray(S.front)&&Array.isArray(S.rear)&&S.front.length===CFG.slots&&S.rear.length===CFG.slots&&S.hand.length<=CFG.hand&&S.deck.length<=60&&S.deck.every(Boolean)&&S.hand.every(Boolean)&&[...S.deck,...S.hand,...S.front,...S.rear].every(okCard);
export const readSaved=()=>{try{const s=JSON.parse(localStorage.getItem(MK)),g=s&&s.G;if(s&&s.v===1&&g&&g.s&&!g.over&&Number.isFinite(g.n)&&okSide(g.s.p)&&okSide(g.s.e)&&g.s.p.hq>0&&g.s.e.hq>0&&g.names&&Object.values(NAMES).includes(g.names.p)&&Object.values(NAMES).includes(g.names.e))return s}catch(e){}return null};
export const persist=()=>{if(!G||G.over||G.busy||G.turn!=='p'||TUT)return;try{const{sel,detail,busy,...g}=G;localStorage.setItem(MK,JSON.stringify({v:1,pf,diff,G:g}))}catch(e){}};
export const clearSave=()=>{set_SAVED(null);try{localStorage.removeItem(MK)}catch(e){}};
export function restore(s){NAMEUSE.clear();set_TUT(null);hideCoach();set_pf(s.pf==='c'?'c':'a');set_diff(['easy','normal','hard'].includes(s.diff)?s.diff:'normal');
const fix=c=>{if(!c)return c;const u={...CARDS[c.id],uid:c.uid,hp:c.hp,ready:!!c.ready,att:!!c.att,bt:Number.isInteger(c.bt)&&c.bt>=0?c.bt:0,imm:!!c.imm,sho:Number.isInteger(c.sho)?c.sho:0},sd=c.sd;u.sd=sd&&typeof sd.n==='string'&&typeof sd.r==='string'&&Number.isFinite(sd.a)?{n:String(sd.n).slice(0,60),r:String(sd.r).slice(0,40),a:+sd.a,c:String(sd.c||'').slice(0,40),j:String(sd.j||'').slice(0,40),y:+sd.y||0}:mkSoldier(u);if(u.sd)NAMEUSE.add(u.sd.n);return u},fs=S=>({f:S.f,tn:S.tn,hq:S.hq,cp:S.cp,max:S.max,deck:S.deck.map(fix),hand:S.hand.map(fix),front:S.front.map(fix),rear:S.rear.map(fix),rx:[0,1].map(i=>{const c=Array.isArray(S.rx)?S.rx[i]:null;return okCard(c)?fix(c):null}),tr:Array.isArray(S.tr)&&S.tr.length===CFG.slots?S.tr.map(x=>x?1:0):[0,0,0,0,0],cmd:CMDS[S.cmd]?S.cmd:null,cdr:Number.isInteger(S.cdr)&&S.cdr>=0?S.cdr:0,nx:S.nx===2?2:0});
set_G({id:next_gidc(),s:{p:fs(s.G.s.p),e:fs(s.G.s.e)},turn:'p',busy:false,over:false,sel:null,detail:null,log:Array.isArray(s.G.log)?s.G.log.slice(0,40).map(String):[],n:s.G.n,names:{p:s.G.names.p,e:s.G.names.e}});
for(const k of['p','e'])for(const r of['deck','hand','front','rear'])G.s[k][r].forEach(c=>{if(c&&c.uid>uid)set_uid(c.uid)});
$('#fs').querySelectorAll('button').forEach(x=>x.classList.toggle('on',x.dataset.v===pf));$('#ds').querySelectorAll('button').forEach(x=>x.classList.toggle('on',x.dataset.v===diff));showFd();render()}
