/* Iron Front — ui/screens.js
 * Telas e páginas: menu, preparação, arquivo, estatísticas, glossário e memorial.
 */
import {G, SAVED, TUT, diff, pf} from '../core/state.js';
import {$, esc} from '../core/util.js';
import {CARDS} from '../data/cards.js';
import {CBIO, CMDS, HAT, cmSel} from '../data/commanders.js';
import {CATN, CDR, CFG, NAMES, TAG} from '../data/config.js';
import {FACT, FH} from '../data/factions.js';
import {ABD, BAS, GLO, KWRE} from '../data/glossary.js';
import {PIC} from '../data/images.js';
import {renderAca} from '../systems/academy/academy.js';
import {SAVE} from '../systems/save/profile.js';
import {MIS_DEF} from '../systems/tutorial/missions.js';
import {renderTrn, tutCheck} from '../systems/tutorial/tutorial.js';
import {sfx, vib} from './audio.js';
import {cardHTML} from './render.js';

let KWSEEN=false;
export const stats=()=>{$('#st').textContent='Vitórias: '+SAVE.w+' · Derrotas: '+SAVE.l+' · Caídos: '+(SAVE.f||0)+(SAVE.w+SAVE.l>0||(SAVE.ac&&SAVE.ac.p&&SAVE.ac.p.length>=8)?'':' · Primeira vez? Comece pela Academia militar.');const bt=$('#bt');if(bt)bt.classList.toggle('on',!(SAVE.ac&&SAVE.ac.p&&SAVE.ac.p.filter(k=>/^f\d$/.test(k)).length>=8))};
let KWT=0;
export function kwShow(ab){const k=$('#kw'),L=[].concat(ab);k.innerHTML='<b>'+L.map(x=>TAG[x]).join(' · ')+'</b>'+L.map(x=>ABD[x].replace(KWRE,'')).join(' ');k.hidden=false;clearTimeout(KWT);KWT=setTimeout(()=>k.hidden=true,5000);KWSEEN=true;sfx('card');vib(15);if(TUT)tutCheck()}
export function cardAt(z){const m=/^([pe])-(hand|front|rear)-(\d+)$/.exec(z);if(!m||!G)return null;return m[2]==='hand'?(m[1]==='p'?G.s.p.hand[+m[3]]:null):G.s[m[1]][m[2]][+m[3]]}
export const gloHTML=()=>'<div class="kwi">Dica: durante a partida, segure o dedo numa carta para ver a palavra-chave dela.</div>'+BAS.map(([a,b])=>`<div class="kwi"><b>${a}</b><br>${b}</div>`).join('')+GLO.map(k=>`<div class="kwi"><b>${TAG[k]}</b><br>${esc(ABD[k].replace(KWRE,''))}</div>`).join('');
export const memHTML=()=>`<div class="kwi">Caíram sob seu comando: <b>${SAVE.f||0}</b>. Os mais recentes:</div>`+(SAVE.m.length?SAVE.m.map(x=>`<div class="kwi"><b>✝ ${esc(x.n)}</b>${x.s?' <span style="color:#ffd24a">'+'★'.repeat(x.s)+'</span>':''}<br>${esc(x.d)}</div>`).join(''):'<div class="kwi">Nenhum soldado caiu ainda.</div>');
export function openPage(t,h){$('#pgt').textContent=t;$('#pgb').innerHTML=h;$('#pg').hidden=false}
export const portrait=(p,k)=>PIC[k]?`<img class="pic" src="${PIC[k]}" alt="Retrato de ${CMDS[k].n}">`:`<svg viewBox="0 0 60 70" role="img" aria-label="Retrato ilustrativo"><rect width="60" height="70" fill="#8a7650"/><circle cx="30" cy="28" r="11" fill="#c9a77c"/><path d="M6 70c0-18 12-24 24-24s24 6 24 24z" fill="#3d4a3a"/>${HAT[p]}<path d="M26 47l4 6 4-6" fill="#e8dfc4"/></svg>`;
export function renderOp(){const df={easy:'Fácil',normal:'Normal',hard:'Difícil'}[diff];$('#op').innerHTML=`<b>ORDEM DE OPERAÇÃO</b><br>Força: ${NAMES[pf]}<br>Comandante: ${CMDS[cmSel[pf]].n}<br>Inimigo: ${pf==='a'?'Potências Centrais':'Aliados'} (comandante sorteado)<br>Dificuldade: ${df}<br>Objetivo: reduzir o QG inimigo (${CFG.hq}) a zero.`}
export function showCm(){const L=Object.keys(CMDS).filter(k=>CMDS[k].f===pf);if(!L.includes(cmSel[pf]))cmSel[pf]=L[0];$('#cs').innerHTML=L.map(k=>`<button data-act="cm" data-v="${k}" class="cmb${k===cmSel[pf]?' on':''}">${portrait(CBIO[k].p,k)}<span>${CMDS[k].n}</span></button>`).join('');const k=cmSel[pf],C=CMDS[k],B=CBIO[k];$('#cc').innerHTML=`<div class="cmx">${portrait(B.p,k)}<div><b>${C.n}</b><em>${B.r}</em></div></div><p>${B.b}</p><p class="cma">★ ${C.t} (custo ${C.c}, recarga ${CDR})</p>`;renderOp()}
const ACAT=[['inf','Infantaria'],['arm','Blindados'],['art','Artilharia'],['air','Aviação'],['ops','Operações'],['rx','Reações'],['cmd','Comandantes']];
export let acat='inf';
export function adet(k){if(CMDS[k]){const C=CMDS[k],B=CBIO[k];return`<div class="cmx">${portrait(B.p,k)}<div><b>${C.n}</b><em>${B.r} · ${C.f==='a'?'Aliados':'Potências Centrais'}</em></div></div><p>${B.b}</p><p class="cma">★ ${C.t} (custo ${C.c}, recarga ${CDR})</p>`}const c=CARDS[k],u=c.cat!=='ops'&&c.cat!=='rx';return`<b>${c.nm}</b><br><em>${c.nat} · ${CATN[c.cat]}</em><br>Custo ${c.cost}${u?` · ⚔${c.atk} ♥${c.hp}`:''}${[c.ab,c.ent,c.cai].filter(Boolean).map(x=>'<p>'+ABD[x]+'</p>').join('')}<p><i>${c.tx||''}</i></p>`}
export function renderArq(){$('#at').innerHTML=ACAT.map(([k,n])=>`<button data-act="ac" data-v="${k}" class="${k===acat?'on':''}">${n}</button>`).join('');$('#ab').innerHTML=acat==='cmd'?Object.keys(CMDS).map(k=>`<button class="ac cmc" data-act="ak" data-v="${k}">${portrait(CBIO[k].p,k)}<b>${CMDS[k].n}</b><small>${CBIO[k].r}</small></button>`).join(''):Object.values(CARDS).filter(c=>c.cat===acat).map(c=>{let h;try{h=cardHTML(c)}catch(e){h='<div class="c"><span class="nm">'+c.nm+'</span></div>'}return`<button class="ac" data-act="ak" data-v="${c.id}">${h}</button>`}).join('');$('#ad').innerHTML='Toque numa carta para ver os detalhes.'}
function renderEst(){const t=SAVE.w+SAVE.l;$('#eb').innerHTML=[['Vitórias',SAVE.w],['Derrotas',SAVE.l],['Aproveitamento',t?Math.round(SAVE.w/t*100)+'%':'—'],['Batalhas',t],['Caídos',SAVE.f||0],['Academia',(SAVE.ac?SAVE.ac.p.filter(k=>/^f\d$/.test(k)).length:0)+'/8 exercícios'],['Missões',SAVE.ms.length+'/'+Object.keys(MIS_DEF).length]].map(([n,v])=>`<div>${n}<b>${v}</b></div>`).join('')}
export function scr(n){document.querySelectorAll('#ov .scr').forEach(e=>e.hidden=e.id!=='s-'+n);if(n==='trn')renderTrn();if(n==='aca')renderAca();if(n==='prep')showFd();if(n==='arq')renderArq();if(n==='est')renderEst()}
export const showFd=()=>{$('#fh').textContent=FH[pf]+' '+FACT[pf].sum;showCm()};
const canResume=()=>(G&&!G.over)||!!SAVED;
export const refreshRs=()=>{const r=$('#rs'),ok=canResume();r.hidden=false;r.disabled=!ok;r.querySelector('small').textContent=ok?(G&&!G.over?'Voltar à partida em andamento.':'Retome seu último combate salvo.'):'Nenhuma partida em andamento.'};
export const set_acat=v=>acat=v;
