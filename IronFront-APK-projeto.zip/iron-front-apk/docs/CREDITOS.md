# Créditos e licenças dos áudios — Iron Front

ATENÇÃO: não tenho acesso à internet neste ambiente e não consegui verificar as licenças. As origens abaixo
vêm dos nomes dos arquivos que você enviou. **Confirme a licença de cada um antes de publicar o jogo.**

| Arquivo original enviado | Origem pelo nome do arquivo | Licença | Usado em |
|---|---|---|---|
| rifle.wav | desconhecida | A CONFIRMAR | infantaria/rifle_tiro_1 |
| rifle_2.wav (4 tiros recortados) | desconhecida | A CONFIRMAR | infantaria/rifle_tiro_2..5 |
| ferrolho_recarga.wav (4 trechos) | desconhecida | A CONFIRMAR | infantaria/ferrolho_recarga_1..4 |
| 303_Vickers_Machine_Gun-_SoundEffectsFactory_com__.mp3 | SoundEffectsFactory.com | A CONFIRMAR (verificar termos do site) | metralhadoras/vickers_rajada_1..2 |
| firing-a-burst-from-a-maxim-machine-gun.wav (2 rajadas recortadas) | desconhecida | A CONFIRMAR | metralhadoras/maxim_mg08_rajada_1..2 |
| freesound_community-clean-machine-gun-burst-98224.mp3 | "freesound_community" (padrão de nome do Pixabay) | A CONFIRMAR (provável Pixabay Content License) | metralhadoras/metralhadora_aviao_rajada |
| 702245__inmotionaudio__gunartl_69thfieldartillerygun01_inmotionaudio_freesamplesunday.wav | Freesound 702245, autor InMotionAudio | A CONFIRMAR na página do Freesound | artilharia/canhao_campanha_tiro |
| heavy_artillery_firing.wav = 839118__artninja__custom_bassy_lasery_atomic_explosion_sound_12202025.wav (arquivos idênticos) | Freesound 839118, autor ArtNinja | A CONFIRMAR na página do Freesound | artilharia/obus_pesado_tiro |
| 844128__artninja__custom_medium_explosion_sound_02032026.wav | Freesound 844128, autor ArtNinja | A CONFIRMAR na página do Freesound | explosoes/explosao_media e explosao_pequena (trecho inicial) |
| 530886__evanboyerman__incoming-artillery-strike-cinematic-explosion.wav | Freesound 530886, autor evanboyerman | A CONFIRMAR na página do Freesound | explosoes/explosao_pesada |
| soundreality-wind-blowing-457954.mp3 | "soundreality" (padrão de nome do Pixabay) | A CONFIRMAR (provável Pixabay Content License) | ambiente/vento_loop |

Se alguma licença exigir atribuição (CC-BY), inclua o crédito do autor numa tela de créditos do jogo.
Licenças "NonCommercial" não permitem uso comercial.

## O que foi feito nos arquivos
Conversão para WAV mono 16 bits (32 kHz; vento em 22,05 kHz), recorte de trechos, fade-out curto e normalização de pico.
O vento foi recortado em 22 s e com emenda cruzada (crossfade de 3 s) para repetir sem corte audível.
